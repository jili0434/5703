// Auto-generated JSX export

export const summaryAnalysisText = `
This student displays a strong inclination toward the performing arts, with a particular aspiration to become a dancer. Their career interest scores reflect a robust artistic score, revealing a deep passion and talent for creativity and movement. They also show significant investigative abilities, suggesting they enjoy understanding and analyzing movement patterns, choreography, and performance techniques. The social aspect of their personality indicates they thrive in environments where they can interact with others, which is essential for collaboration in dance settings.\nIn terms of core values, the student prioritizes hedonism, indicating a preference for pleasure and enjoyment, which aligns perfectly with their commitment to a career in the arts. The value of learning and achievement is also notable, signifying a dedication to personal growth, which is crucial for mastering the complex skills required in dance. Their higher score in power and status reflects a desire for recognition in their field, further reinforcing their dedication to pursuing a career where they can perform and be acknowledged.\nAs an extrovert, this student likely enjoys the spotlight and social interactions inherent in performance arts. The MBTI profile indicates a good balance between intuition and feeling, suggesting they approach dance both creatively and emotionally, allowing them to express themselves effectively through movement. Although their scores in conventional and enterprising attributes are lower, indicating less interest in business or managerial roles, they still have a balanced approach to creativity and supporting their artistic ambitions.
`;

export const recommendedFOE = {
  title1: "1004 Dance",
  paragraphs1: [
    "After a thorough analysis of this student's characteristics, the most recommended specific direction is: 1004 Dance. This field encompasses training in various dance forms, choreography, and performance techniques, aligning directly with their dream of becoming a dancer and emphasizing their artistic talents and passion for the performing arts.",
    "The student possesses a strong foundation in areas crucial for a successful dance career, particularly given their high artistic, investigative, and social scores. This combination will aid them in understanding dance not just as a physical activity but as an art form that requires analysis, emotion, and connectivity with audiences. Their significant score in creativity reflects their potential for choreography, while their investigative nature will support a deep understanding of dance history and techniques.",
    "The personality traits of being an extrovert combined with a feeling preference contribute to a natural aptitude for performances and collaborations with fellow dancers. They are likely to thrive in environments that encourage creativity and experimentation. Additionally, their parents' support offers a stable foundation for pursuing this competitive field, where financial concerns are often significant, but the student's passion for dance may outweigh these challenges.",
    "Qualification recommendation: The ideal qualification level for 1004 Dance is typically at least a bachelor's degree from a reputable performance arts institution or conservatory. This level of education helps the student prepare for a professional career in dance while providing opportunities for networking and practical experience through performances and workshops.",
  ],
  title2: "1005 Arts",
  paragraphs2: [
    "The second recommended field of education is: 1005 Arts. This area includes various disciplines in visual and performance arts, such as theater, music, and design, which aligns well with the student's artistic aspirations and provides a wider range of career paths related to creativity.",
    "Given their artistic score, this student is in an excellent position to explore roles in arts management, choreography, or performance art that combine their love for dance with other artistic expressions. Their ability to work well with others (as indicated by a solid social interest) will be beneficial when collaborating on interdisciplinary projects or community arts initiatives.",
    "Again, their strong desire for pleasure and higher value on achievement will encourage them to seek out opportunities that allow them to flourish creatively. The interdisciplinary nature of 1005 Arts promotes flexibility and exploration, allowing the student to discover various interests while honing their skill set.",
    "Qualification recommendation: The ideal qualification level for 1005 Arts is also a bachelor's degree, with many students enhancing their career prospects through additional certifications in specific artistic disciplines. A broad education in the arts will couple well with their dedicated pursuit of dance, opening pathways for further artistic endeavors.",
  ],
  title3: "0803 Management",
  paragraphs3: [
    "The third recommended field is: 0803 Management. Although this direction is less aligned with their primary interest in dance, it could serve as a fallback option for those concerned with career stability and financial security.",
    "In analyzing this student's profile, a role in arts management or event management within the arts sector could be a viable opportunity. Their high scores in learning and achievement can prepare them for leadership roles in managing dance troupes, festivals, or arts organizations, combining their passion for dance with business acumen.",
    "While their current passion lies firmly in dance, an educational foundation in management would provide essential skills for running an arts organization, understanding financial management, and promoting artistic work. This dual approach could empower them with the security they value while allowing opportunities to remain connected to the performing arts.",
    "Qualification recommendation: The ideal qualification level for 0803 Management would typically be a bachelor's degree in business or arts management. This education will help ensure they understand both the practical and theoretical aspects of management within the arts, providing a solid backup plan should their primary aspirations face challenges.",
  ],
};

export const universityRecommendation1 = {
  university: "New York University (NYU)",
  major: "Bachelor of Fine Arts in Dance",
  note: "Comprehensive curriculum combining performance, choreography, and movement.",
  exam: "A-level",
  score: "33.0/100 (33/100)",
  special: "Audition required.",
};

export const universityRecommendation2 = {
  university: "California Institute of the Arts (CalArts)",
  major: "Bachelor of Fine Arts in Dance",
  note: "Focus on contemporary dance styles and performance practices.",
  exam: "A-level",
  score: "33.0/100 (33/100)",
  special: "Audition and portfolio required.",
};

export const universityRecommendation3 = {
  university: "University of Southern California (USC)",
  major: "Bachelor of Arts in Dance",
  note: "Interdisciplinary approach to dance with emphasis on collaboration across various art forms.",
  exam: "A-level",
  score: "33.0/100 (33/100)",
  special: "Audition required.",
};

export const universityRecommendation4 = {
  university: "The Juilliard School",
  major: "Bachelor of Fine Arts in Dance",
  note: "Intensive training in dance performance and choreography.",
  exam: "A-level",
  score: "33.0/100 (33/100)",
  special: "Audition and interview required.",
};

export const universityRecommendation5 = {
  university: "University of California, Los Angeles (UCLA)",
  major: "Bachelor of Arts in World Arts and Cultures/Dance",
  note: "Explores dance within the context of diverse cultures and artistic practices.",
  exam: "A-level",
  score: "33.0/100 (33/100)",
  special: "Audition required.",
};

export const universityRecommendations = [
  universityRecommendation1,
  universityRecommendation2,
  universityRecommendation3,
  universityRecommendation4,
  universityRecommendation5,
];

export const guidanceParagraph = `
"Although pursuing a career as a dancer aligns well with your dream, based on your interest scores and personality traits, it may benefit you to explore other aspects of the performing arts or related fields. Your artistic score is notable, yet your social score suggests a struggle with frequent emotional interaction, which can be challenging in a highly collaborative performance environment. To better gauge and develop your potential, consider engaging in smaller group performances or workshops that allow for both collaboration and individuality. 

Furthermore, exploring roles in artistic direction, choreography, or arts management could provide you with stability while still being involved in the dance world. These roles will capitalize on your artistic abilities while offering a more structured career path. We encourage you to take part in administrative or managerial volunteer opportunities in the arts sector, as this will not only broaden your experience but also sharpen your skills in managing creative projects. Alongside these explorations, developing a secondary skill set in areas such as event management or arts education can provide alternative career options in the performing arts sector. Please work with your parents to set incremental goals, like participating in community arts projects or developing a personal project, to find the right fit for your aspirations."
`;

export const navItems = [
  { text: "Personal information analysis", path: "/", bg: "#d0ebff" },
  { text: "Recommended Field of Study", path: "/foe", bg: "#ffe3e3" },
  { text: "Suggested Universities and Majors", path: "/universities", bg: "#fff9db" },
  { text: "Next Step Guidance", path: "/guidance", bg: "#e6fcf5" },
];
