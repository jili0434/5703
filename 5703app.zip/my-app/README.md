# 🎓 Intelligent Study Abroad Advisory System

This project is an intelligent recommendation platform for academic advancement. It leverages a React-based frontend and a FastAPI-powered backend to generate personalized analysis reports, suggested fields of study, and university recommendations based on student-provided information.

---

## 📁 Project Structure Overview

```
MY-APP/
├── backend/                     # Backend services (FastAPI)
│   ├── api_server.py            # Main FastAPI service
│   ├── main.py                  # Backend entry point
│   ├── final_output.jsx         # Template for generated recommendations
│   ├── full_data_with_labels.csv# Dataset
│   ├── parse_and_generate_final_jsx.py  # Data processing
│   ├── validate_api_key.py      # API Key validation
│   └── prompt_uni_templates/    # Prompt templates
│
├── src/                         # Frontend source code
│   └── 5703/                    # Pages and components
│       ├── context/             # Global state management
│       ├── *.jsx                # Page components
│       ├── mockProfile.js       # Simulated user input (for debugging)
│       └── mockOutput.js        # Simulated backend response (for debugging)
│
├── assets/                      # Static assets
├── public/                      # Public directory
├── App.jsx / App.css / index.css / main.jsx
└── README.md
```

---

## ⚙️ Prerequisites

- Python 3.8+
- Node.js 16+
- npm 8+

### Python Dependencies
Make sure to install the required Python packages:

```
# backend/requirements.txt
openai>=1.3.8
pandas>=1.3.0
fastapi>=0.95.0
uvicorn[standard]>=0.18.3
```

---

## 🚀 Quick Start Guide

Ensure you are in the root directory (`MY-APP`) and execute the following:

### 1. Install Dependencies

```bash
# Install backend dependencies (using virtual environment recommended)
pip install -r backend/requirements.txt

# Install frontend dependencies
npm install
```

### 2. Start Services

```bash
# Start FastAPI backend
uvicorn backend.api_server:app --reload

# Start frontend Vite dev server
npm run dev
```

---

## 🔧 Key Features

- 📄 **Form Input**: Collects student's background, academics, interests, and MBTI.
- 📊 **Personalized Analysis**: Generates visual charts like MBTI bars, value radar, and career interest.
- 🎯 **Field Recommendations**: Suggests top fields of study aligned with user's profile.
- 🎓 **University Suggestions**: Recommends institutions and majors, including admission criteria.
- 📘 **Guidance Section**: Offers follow-up academic and career planning advice.

