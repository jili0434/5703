
from openai import OpenAI
import pandas as pd
import os
from datetime import datetime
import re

def validate_api_key(client):
    try:
        client.models.list()
        print("✅ OpenAI API key is valid.")
    except Exception as e:
        print("❌ Invalid API Key:", e)

def generate_custom_prompt_response(system_prompt: str, user_prompt: str) -> str:
    if not client.api_key:
        return "Error: OPENAI_API_KEY is not set or invalid."

    try:
        response = client.chat.completions.create(
            model="gpt-4o-mini",
            messages=[
                {"role": "system", "content": system_prompt.strip()},
                {"role": "user", "content": user_prompt.strip()}
            ]
        )
        return response.choices[0].message.content.strip()
    except Exception as e:
        return f"An error occurred while contacting OpenAI: {str(e)}"

def load_random_user_prompt(file_path: str) -> str:
    try:
        df = pd.read_csv(file_path)
        random_row = df.sample(n=1).iloc[0]
        user_input_str = str(random_row.to_dict())
        print("\nSelected random sample as user prompt:")
        print(user_input_str)
        return user_input_str, random_row
    except Exception as e:
        print("Error loading data:", e)
        return input("Enter user prompt manually (fallback): ")

def get_unique_filename(base_filename: str) -> str:
    if not os.path.exists(base_filename):
        return base_filename

    base, ext = os.path.splitext(base_filename)
    counter = 1
    while True:
        new_filename = f"{base}_{counter}{ext}"
        if not os.path.exists(new_filename):
            return new_filename
        counter += 1

def write_response_to_file(user_prompt: str, response: str, folder: str = ".", csv_name: str = "response_log.csv"):
    os.makedirs(folder, exist_ok=True)
    path = os.path.join(folder, csv_name)
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    row = pd.DataFrame([{
        "timestamp": timestamp,
        "user_prompt": user_prompt,
        "gpt_response": response
    }])

    if not os.path.exists(path):
        row.to_csv(path, index=False, encoding='utf-8-sig')
    else:
        row.to_csv(path, mode='a', index=False, header=False, encoding='utf-8-sig')

    print(f"\n✅ Output appended to '{path}'")


def save_structured_jsx(foe_titles_paragraphs: list, university_list: list, output_file="generated_structured.jsx"):
    with open(output_file, "w", encoding="utf-8") as f:
        f.write("// Auto-generated structured JSX data\n\n")

        # FOE block
        f.write("export const recommendedFOE = {\n")
        for idx, (title, paragraphs) in enumerate(foe_titles_paragraphs, start=1):
            f.write(f'  title{idx}: "{title}",\n')
            f.write(f'  paragraphs{idx}: [\n')
            for line in paragraphs:
                f.write(f'    "{line.strip()}",\n')
            f.write("  ],\n")
        f.write("};\n\n")

        # University blocks
        for i, uni in enumerate(university_list, start=1):
            f.write(f"export const universityRecommendation{i} = {{\n")
            for k, v in uni.items():
                f.write(f'  {k}: "{v.strip()}",\n')
            f.write("};\n\n")

        # Group list
        f.write("export const universityRecommendations = [\n")
        for i in range(1, len(university_list) + 1):
            f.write(f"  universityRecommendation{i},\n")
        f.write("];\n")

    print(f"\n✅ Structured JSX saved to: {output_file}")

def parse_and_save_jsx(gpt_foe_text: str, gpt_uni_text: str, output_file="structured_output.jsx"):
    # === Parse FOEs ===
    foe_matches = re.findall(r"(?:(\d+)[\).\s]*)?recommended FOE[:：]?\s*(\d{4}) ([^\n]+)\n(.+?)(?=\n\d+[\).\s]*|$)", gpt_foe_text, re.DOTALL)
    foe_blocks = []
    for i, (_, code, title, content) in enumerate(foe_matches, start=1):
        paragraphs = [p.strip() for p in content.strip().split("\n") if p.strip()]
        foe_blocks.append((f"{code} {title}", paragraphs))

    # === Parse University Recommendations ===
    uni_matches = re.findall(
        r"\*\*Recommendation (\d+)\*\*\n"
        r"university: \"?([^\n\"]+)\"?\n"
        r"major: \"?([^\n\"]+)\"?\n"
        r"note: \"?([^\n\"]+)\"?\n"
        r"exam: \"?([^\n\"]+)\"?\n"
        r"score: \"?([^\n\"]+)\"?\n"
        r"special: \"?([^\n\"]+)\"?",
        gpt_uni_text
    )

    university_list = []
    for (_, university, major, note, exam, score, special) in uni_matches:
        university_list.append({
            "university": university,
            "major": major,
            "note": note,
            "exam": exam,
            "score": score,
            "special": special
        })

    # === Save to JSX ===
    save_structured_jsx(foe_blocks, university_list, output_file)




def extract_foe_and_country(response: str) -> list:
    foes = re.findall(r"recommended FOE:\s*(\d{4}\s[\w\s&]+)\n", response)
    return foes[:3]

def load_country_prompt(country: str) -> str:
    known_countries = {
        "australia": "prompt_uni_australia.txt",
        "united kingdom": "prompt_uni_uk.txt",
        "uk": "prompt_uni_uk.txt",
        "canada": "prompt_uni_canada.txt",
        "new zealand": "prompt_uni_new_zealand.txt",
        "USA":"prompt_uni_usa.txt",
        "United States":"prompt_uni_usa.txt",
        "nz": "prompt_uni_new_zealand.txt"
    }

    key = country.strip().lower()
    filename = known_countries.get(key, "prompt_uni_others.txt")
    path = os.path.join("prompt_uni_templates", filename)

    if not os.path.exists(path):
        raise FileNotFoundError(f"Prompt file not found for country: {country} → {path}")

    with open(path, "r", encoding="utf-8") as f:
        return f.read()

def write_response_to_file(user_prompt: str, response: str, folder: str = ".", csv_name: str = "response_log.csv"):
    os.makedirs(folder, exist_ok=True)
    path = os.path.join(folder, csv_name)
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    row = pd.DataFrame([{
        "timestamp": timestamp,
        "user_prompt": user_prompt,
        "gpt_response": response
    }])
    if not os.path.exists(path):
        row.to_csv(path, index=False, encoding='utf-8-sig')
    else:
        row.to_csv(path, mode='a', index=False, header=False, encoding='utf-8-sig')
    print(f"\n✅ Output appended to '{path}'")

def main():
    validate_api_key()

    # 确保 prompt2.txt 已经上传到当前目录
    with open("prompt2.txt", "r", encoding="utf-8") as f:
        system_input = f.read()

    # 确保 csv 已上传
    user_input_str, user_row = load_random_user_prompt("full_data_with_labels.csv")
    result = generate_custom_prompt_response(system_input, user_input_str)
 #   print("\nResponse:\n", result)
    print("\n🧠 Part 1 - FOE Recommendation:\n", result)
    write_response_to_file(user_input_str, result)

    # === Extract FOE + Country + academic ===
    foes = extract_foe_and_country(result)
    country = str(user_row["preferred_country"]).strip()
    academic = str(user_row["academic"]).strip()
    print(f"\n🌍 Preferred Country: {country}\n🌍 academic: {academic}\n🎯 FOEs: {foes}")

    # === Load Country-Specific University Prompt ===
    try:
        country_prompt_template = load_country_prompt(country)
    except FileNotFoundError as e:
        print(e)
        return

    # === Compose second prompt ===
    uni_prompt = f"""Based on the academic, following Fields of Education and preferred country:
FOE 1: {foes[0] if len(foes) > 0 else 'N/A'}
FOE 2: {foes[1] if len(foes) > 1 else 'N/A'}
FOE 3: {foes[2] if len(foes) > 2 else 'N/A'}
Preferred Country: {country}
academic: {academic}
{country_prompt_template}
"""

    # === Second GPT Call ===
    uni_response = generate_custom_prompt_response(uni_prompt, user_input)
    print("\n🏫 Part 2 - University Recommendations:\n", uni_response)
    write_response_to_file(user_input, uni_response, csv_name="university_recommendation_log.csv")

    # === Save to JSX ===
    parse_and_save_jsx(result, uni_response)
    parse_and_generate_final_jsx(result, uni_response)