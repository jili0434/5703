from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
import sys
import os
from backend.main import generate_recommendation  # ✅ 正确导入函数

sys.path.append(os.path.dirname(os.path.abspath(__file__)))

app = FastAPI()

# CORS 允许跨域请求
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.post("/api/analyze")
async def analyze(request: Request):
    try:
        profile = await request.json()
        print("✅ Received profile:", profile)

        result = generate_recommendation(profile)  # ✅ 返回结构化数据
        return result  # ✅ FastAPI 自动转为 JSON 响应
    except Exception as e:
        print("❌ Error in backend:", e)
        return {"error": str(e)}
