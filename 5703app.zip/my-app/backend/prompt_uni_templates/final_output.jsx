// Auto-generated JSX export

export const recommendedFOE = {
  title1: "0802 Communication and Media",
  paragraphs1: [
    "After in-depth analysis of this student's characteristics, my top recommended specific direction is: 0802 Communication and Media. This field encompasses various aspects of media creation, social media strategy, and digital storytelling, aligning well with the student's dream of becoming an influencer. With his strong interest in social interaction and artistic expression, he would thrive in an engaging media environment that allows for creativity and audience connection.",
    "This student demonstrates a good combination of social skills and artistic interest, which can be effectively utilized in content creation and community engagement within the media landscape. The 0802 Communication and Media field focuses on developing skills in multimedia storytelling, marketing strategies, and audience analysis. The blend of academic theory with practical projects makes this educational path suitable for him, encouraging collaborative work while providing flexibility in expressing creativity.",
    "The INFJ personality type further supports a focus on meaningful content creation, as he is likely to resonate with audiences through personal stories and empathetic engagement. By pursuing a qualification in this area, he could carve out a niche as a content creator focused on lifestyle, identity, or social issues – topics that often resonate well in today's digital age.",
    "Qualification recommendation: The ideal qualification level for 0802 Communication and Media is at the undergraduate level, where he can gain foundational skills in media, communication, and marketing. A bachelor's degree would provide him with necessary training to not only understand the academic concepts but also hone his practical skills in producing and marketing content.",
  ],
  title2: "0803 Marketing and Advertising",
  paragraphs2: [
    "Following closely, my second recommendation is: 0803 Marketing and Advertising. This field closely relates to his goal, focusing on brand management and promotional strategy, both of which are vital for aspiring influencers looking to develop and maintain their brand identity across various platforms.",
    "With his high score in conventional interests (57), he has the organizational skills and strategic mindset that can benefit the discipline of marketing. He will appreciate the structured approach to campaigns and audience targeting, which can allow him to apply his strong financial awareness and creativity effectively.",
    "From the INFJ standpoint, this might also provide him with opportunities to create thoughtful and impactful marketing strategies that resonate with an audience deeply, leveraging emotional storytelling alongside traditional marketing techniques.",
    "Qualification recommendation: The ideal qualification level for 0803 Marketing and Advertising is also at the undergraduate level. Specialized courses in digital marketing, social media strategies, and consumer behavior would enhance his capability to understand the market's needs and effectively engage his target audience.",
  ],
  title3: "0901 Creative Arts",
  paragraphs3: [
    "My third recommendation is: 0901 Creative Arts. This educational field represents a broader spectrum of opportunities for artistic expression, covering various forms of art, performance, and media, which can complement his identity as an influencer by allowing him to fuse creativity with commerce.",
    "His moderate artistic score (32) reflects a potential for creative interpretation, which can be advantageous in fields like photography, video production, or graphic design as part of his content creation strategy. The endorsement of creative arts would allow him to develop skills that not only enhance his influencer capabilities but can also provide an outlet for self-expression and emotional depth, aligning well with the empathetic tendencies of his INFJ personality.",
    "This field offers room for experimentation, making it a fertile ground for him to explore different artistic avenues while framing his personal brand, which is essential for a career as an influencer.",
    "Qualification recommendation: The ideal qualification level for 0901 Creative Arts could range from diplomas to bachelor's degrees, focusing on specific artistic skills related to visual media or performing arts, providing essential training for a career built around creativity and personal branding.",
  ],
};

export const universityRecommendation1 = {
  university: "University of Toronto",
  major: "Bachelor of Arts in Communication",
  note: "This program focuses on the study of communication processes and the impact of media on society.",
  exam: "A Level",
  score: "63.0/100 (not specified)",
  special: "None",
};

export const universityRecommendation2 = {
  university: "York University",
  major: "Bachelor of Commerce in Marketing",
  note: "This program emphasizes marketing principles, consumer behavior, and strategic marketing within various sectors.",
  exam: "A Level",
  score: "63.0/100 (not specified)",
  special: "None",
};

export const universityRecommendation3 = {
  university: "Ryerson University",
  major: "Bachelor of Arts in Creative Industries",
  note: "This interdisciplinary program blends creative arts and business, focusing on innovation and entrepreneurship in the creative sector.",
  exam: "A Level",
  score: "62.0/100 (not specified)",
  special: "Portfolio required.",
};

export const universityRecommendation4 = {
  university: "Simon Fraser University",
  major: "Bachelor of Media Arts",
  note: "This program explores the relationship between art and media through various forms of digital media.",
  exam: "A Level",
  score: "62.0/100 (not specified)",
  special: "Portfolio required.",
};

export const universityRecommendation5 = {
  university: "University of Alberta",
  major: "Bachelor of Arts in Arts and Cultural Management",
  note: "This program prepares students for a career in managing arts organizations, focusing on cultural policy and management strategies.",
  exam: "A Level",
  score: "63.0/100 (not specified)",
  special: "None",
};

export const universityRecommendations = [
  universityRecommendation1,
  universityRecommendation2,
  universityRecommendation3,
  universityRecommendation4,
  universityRecommendation5,
];

export const guidanceParagraph = `
"While your dream career in politics aligns with your altruistic values and personal characteristics, factors such as a low score in extroversion indicate that you might find the public engagement and networking aspects of a political career challenging. As a strong INFP, you have the potential for deep empathy and idealism, which can be powerful in politics; however, your lower social and enterprising scores suggest you may struggle with traditional political dynamics. 
To enhance your suitability for a career in politics, consider volunteering for community organizations, participating in student government, or joining debate clubs to build confidence in public speaking and interacting with diverse groups. Engaging in activities that require collaboration and advocacy will allow you to gradually develop your skills in persuasion and leadership while staying true to your values. Simultaneously, keep a journal of events and issues in society that you are passionate about, as reflecting on these can further clarify your political goals and viewpoints.
If you find politics to be overwhelmingly social, you can think about roles in policy analysis or community organization where you can influence change without being in the spotlight constantly. Set small goals, such as attending a city council meeting or organizing a community event, to cultivate your experience and comfort level in political settings, and consistently seek feedback from mentors or peers to refine your approach."
`;

export const navItems = [
  { text: "Personal information analysis", path: "/", bg: "#d0ebff" },
  { text: "Recommended Field of Study", path: "/foe", bg: "#ffe3e3" },
  { text: "Suggested Universities and Majors", path: "/universities", bg: "#fff9db" },
  { text: "Next Step Guidance", path: "/guidance", bg: "#e6fcf5" },
];
