from backend.validate_api_key import validate_api_key
from backend.parse_and_generate_final_jsx import parse_and_generate_final_jsx
from openai import OpenAI
import pandas as pd
import os
from datetime import datetime
import re

# ===== 设置 OpenAI Key =====
api_key = "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"  # 或放置在环境变量中更安全
client = OpenAI(api_key=api_key)

def validate_api_key(client):
    try:
        client.models.list()
        print("✅ OpenAI API key is valid.")
    except Exception as e:
        print("❌ Invalid API Key:", e)


def generate_custom_prompt_response(system_prompt: str, user_prompt: str) -> str:
    try:
        response = client.chat.completions.create(
            model="gpt-4o-mini",
            messages=[
                {"role": "system", "content": system_prompt.strip()},
                {"role": "user", "content": user_prompt.strip()}
            ]
        )
        return response.choices[0].message.content.strip()
    except Exception as e:
        return f"An error occurred while contacting OpenAI: {str(e)}"

def write_response_to_file(user_prompt: str, response: str, folder: str = ".", csv_name: str = "response_log.csv"):
    os.makedirs(folder, exist_ok=True)
    path = os.path.join(folder, csv_name)
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    row = pd.DataFrame([{
        "timestamp": timestamp,
        "user_prompt": user_prompt,
        "gpt_response": response
    }])
    if not os.path.exists(path):
        row.to_csv(path, index=False, encoding='utf-8-sig')
    else:
        row.to_csv(path, mode='a', index=False, header=False, encoding='utf-8-sig')
    print(f"\n✅ Output appended to '{path}'")

def load_random_user_prompt(file_path: str):
    df = pd.read_csv(file_path)
    random_row = df.sample(n=1).iloc[0]
    user_input_str = str(random_row.to_dict())
    print("\nSelected random sample as user prompt:")
    print(user_input_str)
    return user_input_str, random_row

# ===== 主程序 =====
if __name__ == "__main__":
    validate_api_key()

    # Step 1: 读取 system prompt
    with open("backend/prompt2.txt", "r", encoding="utf-8") as f:
        system_input = f.read()

    # Step 2: 加载样本数据
    user_input_str, user_row = load_random_user_prompt("full_data_with_labels.csv")

    # Step 3: GPT1 – FOE推荐
    result = generate_custom_prompt_response(system_input, user_input_str)
    print("\n🧠 Part 1 - FOE Recommendation:\n", result)
    write_response_to_file(user_input_str, result)

    # Step 4: 提取国家与学术成绩
    country = str(user_row["preferred_country"]).strip()
    academic = str(user_row["academic"]).strip()
    try:
        with open(f"backend/prompt_uni_templates/prompt_uni_{country.lower().replace(' ', '_')}.txt", "r", encoding="utf-8") as f:
            country_prompt_template = f.read()
    except Exception as e:
        print(f"✘ Failed to load country template: {e}")
        exit()

    # Step 5: GPT2 – 大学推荐
    uni_prompt = f"""Based on the academic, following Fields of Education and preferred country:
Preferred Country: {country}
academic: {academic}
{country_prompt_template}
"""
    uni_response = generate_custom_prompt_response(uni_prompt, user_input_str)
    print("\n🏫 Part 2 - University :\n", uni_response)
    write_response_to_file(user_input_str, uni_response, csv_name="university_recommendation_log.csv")

    # Step 6: JSX生成
    parse_and_generate_final_jsx(result, uni_response)


# 其他部分不动，底部加上这个函数（或替换原来的 main 执行逻辑）

def generate_recommendation(profile: dict) -> dict:
    try:
        # Step 1: 系统 prompt
        with open("backend/prompt2.txt", "r", encoding="utf-8") as f:
            system_input = f.read()
        user_input_str = str(profile)

        # Step 2: GPT 生成 FOE 推荐
        result = generate_custom_prompt_response(system_input, user_input_str)

        # Step 3: 国家与学术提取
        country = str(profile.get("preferred_country", "")).strip()
        academic = str(profile.get("academic", "")).strip()

        try:
            with open(f"backend/prompt_uni_templates/prompt_uni_{country.lower().replace(' ', '_')}.txt", "r", encoding="utf-8") as f:
                country_prompt_template = f.read()
        except Exception:
            country_prompt_template = ""

        # Step 4: GPT 生成大学推荐
        uni_prompt = f"""Based on the academic, following Fields of Education and preferred country:
Preferred Country: {country}
academic: {academic}
{country_prompt_template}
"""
        uni_response = generate_custom_prompt_response(uni_prompt, user_input_str)

        # Step 5: 输出结构化结果（写入 JSX 文件 + 返回结构体）
        return parse_and_generate_final_jsx(result, uni_response)

    except Exception as e:
        print("❌ Error generating recommendation:", e)
        return {"error": str(e)}




# uvicorn backend.api_server:app --reload