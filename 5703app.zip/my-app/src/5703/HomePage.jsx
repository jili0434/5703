import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { useAdvisor } from "./context/AdvisorContext";
import countries from "./countries";
import mockProfile from "./mockProfile";

const scoreOptions = (max) => Array.from({ length: max + 1 }, (_, i) => i);

const navy = "#031A47";
const red = "#EB2B4A";
const light = "#ffffff";
const gray = "#f4f6fa";
const darkText = "#111827";
const softShadow = "0 4px 12px rgba(0,0,0,0.1)";

export default function HomePage() {
  const { profile, setProfile, setOutput, setProgressStep } = useAdvisor();
  const navigate = useNavigate();
  const [step, setStep] = useState(1);

  const handleChange = (field, value) => {
    setProfile((prev) => ({ ...prev, [field]: value }));
  };

  const handleNext = () => setStep((prev) => prev + 1);
  const handleBack = () => setStep((prev) => prev - 1);

  const renderInput = (label, key, type = "text", placeholder = "", options = []) => (
    <div style={{ display: "flex", flexDirection: "column", rowGap: "0.25rem" }} key={key}>
      <label style={{ fontWeight: "bold", color: darkText }}>{label}</label>
      {options.length > 0 ? (
        <select
          value={profile[key] || ""}
          onChange={(e) => handleChange(key, e.target.value)}
          style={inputStyle}
        >
          <option value="" disabled>Select...</option>
          {options.map((opt) => (
            <option key={opt} value={opt}>{opt}</option>
          ))}
        </select>
      ) : (
        <input
          type={type}
          value={profile[key] || ""}
          onChange={(e) => handleChange(key, e.target.value)}
          placeholder={placeholder}
          style={inputStyle}
        />
      )}
    </div>
  );

  const renderStep = () => {
    const grid2 = { display: "grid", gridTemplateColumns: "1fr 1fr", gap: "1rem" };
    const grid3 = { display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: "1rem" };
    const steps = [
      ["Basic Information", grid2, [
        ["First Letter of Surname", "first_letter_surname"],
        ["Age", "age", "select", "", scoreOptions(30)],
        ["Gender", "gender"],
        ["First Language", "first_language"],
        ["Other Language", "other_language"],
        ["Academic", "academic", "select", "", scoreOptions(100)],
        ["Subject 1", "subject1"],
        ["Subject 2", "subject2"],
        ["Subject 3", "subject3"]
      ]],
      ["Background Information", grid2, [
        ["Country Born", "country_born", "select", "", countries],
        ["Current Country", "current_country", "select", "", countries],
        ["Current City", "current_city"],
        ["Preferred Country", "preferred_country", "select", "", countries],
        ["Type of School", "type_of_school"],
        ["Secondary Qualification", "secondary_qualification"],
        ["Dream Career", "dream_career"],
        ["Work Experience", "work_experience"]
      ]],
      ["Career Interest Scores", grid3, ["artistic", "social", "investigative", "conventional", "enterprising", "realistic"]],
      ["Core Value Scores", grid3, ["hedonism", "power_and_status", "altruism", "learning_and_achievement", "finance", "security"]],
      ["Scenario-based Evaluation", grid3, [["Q1", "q1"], ["Q2", "q2"], ["Q3", "q3"]]],
      ["Family & Planning", grid2, [
        ["Father's Education", "father_education"],
        ["Mother's Education", "mother_education"],
        ["Father's Occupation", "father_occupation"],
        ["Mother's Occupation", "mother_occupation"],
        ["Annual Budget (USD)", "annual_budget_usd"],
        ["Preferred FOE 1", "preferred_foe_1"],
        ["Preferred FOE 2", "preferred_foe_2"],
        ["Preferred FOE 3", "preferred_foe_3"],
        ["Notes", "notes"],
        ["Concern", "concern"],
        ["Support", "support"]
      ]],
      ["MBTI Score (0–10)", grid2, ["extrovert", "introvert", "sensing", "intuition", "thinking", "feeling", "judging", "perceiving"]]
    ];

    if (step < 1 || step > steps.length) return null;

    const [title, layout, fields] = steps[step - 1];
    return (
      <>
        <h2 style={titleStyle}>{title}</h2>
        <div style={layout}>
          {fields.map((f) => typeof f === 'string' ?
            renderInput(f[0].toUpperCase() + f.slice(1), f, "select", "", scoreOptions(60)) :
            renderInput(...f))}
        </div>
      </>
    );
  };

  return (
    <div style={sectionStyle}>
      <form
        onSubmit={async (e) => {
          e.preventDefault();
          if (step < 7) {
            handleNext();
          } else {
            localStorage.setItem("profile", JSON.stringify(profile));
            setProgressStep(0);
            setOutput(null);
            navigate("/loading");
            try {
              const response = await fetch("http://localhost:8000/api/analyze", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify(profile)
              });
              const result = await response.json();
              console.log("📦 Received result:", result); // 👈 加这一句


              setOutput(result);
              navigate("/result");
            } catch (error) {
              alert("❌ Failed to connect: " + error.message);
            }
          }
        }}
        style={cardStyle}
      >
        {renderStep()}
        <div style={{ display: "flex", justifyContent: step > 1 ? "space-between" : "flex-end", marginTop: "1rem" }}>
          {step > 1 && (
            <button type="button" onClick={handleBack} style={backButtonStyle}>← Back</button>
          )}
          <button type="submit" style={nextButtonStyle}>
            {step === 7 ? "Submit →" : "Next →"}
          </button>
        </div>
      </form>
      <button
        onClick={async () => {
          setProfile(mockProfile);
          localStorage.setItem("profile", JSON.stringify(mockProfile));
          setProgressStep(0);
          setOutput(null);
          navigate("/loading");
          try {
            const response = await fetch("http://localhost:8000/api/analyze", {
              method: "POST",
              headers: { "Content-Type": "application/json" },
              body: JSON.stringify({ ...mockProfile, debug: true })
            });
            const result = await response.json();
            setOutput(result);
            navigate("/result");
          } catch (error) {
            alert("❌ Debug failed: " + error.message);
          }
        }}
        style={debugButtonStyle}
      >
        🚀 Debug with Mock Data
      </button>
    </div>
  );
}

const inputStyle = {
  padding: "0.75rem",
  border: "1px solid #d1d5db",
  borderRadius: "0",
  fontSize: "1rem",
  backgroundColor: light,
  color: darkText,
  boxShadow: "0 1px 2px rgba(0,0,0,0.04)",
  lineHeight: "1.2"
};

const cardStyle = {
  width: "100%",
  maxWidth: "1000px",
  maxHeight: "90vh",
  display: "flex",
  flexDirection: "column",
  gap: "1rem",
  backgroundColor: light,
  padding: "2rem",
  borderRadius: "0",
  boxShadow: softShadow,
  overflowY: "auto"
};

const backButtonStyle = {
  backgroundColor: gray,
  color: darkText,
  padding: "0.8rem 1.5rem",
  borderRadius: "0",
  border: "none",
  fontWeight: "bold",
  cursor: "pointer"
};

const nextButtonStyle = {
  padding: "0.8rem 1.5rem",
  backgroundColor: red,
  color: light,
  fontWeight: "bold",
  border: "none",
  borderRadius: "0",
  cursor: "pointer"
};

const debugButtonStyle = {
  position: "fixed",
  bottom: 20,
  right: 20,
  padding: "0.6rem 1.2rem",
  backgroundColor: red,
  color: light,
  borderRadius: "0",
  border: "none",
  fontWeight: "bold",
  cursor: "pointer"
};

const titleStyle = {
  fontSize: "2rem",
  fontWeight: "600",
  color: darkText,
  marginBottom: "0.5rem",
  borderBottom: `2px solid ${gray}`,
  paddingBottom: "0.3rem",
  lineHeight: "1.2"
};

const sectionStyle = {
  position: "fixed",
  top: 0,
  left: 0,
  width: "100vw",
  height: "100vh",
  display: "flex",
  justifyContent: "center",
  alignItems: "center",
  backgroundColor: navy,
  padding: "2rem 7rem",
  boxSizing: "border-box",
  fontFamily: "'Segoe UI', 'Helvetica Neue', sans-serif"
};
