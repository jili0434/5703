const mockProfile = {
  first_letter_surname: "L",
  age: "17",
  gender: "Female",
  first_language: "Mandarin",
  other_language: "English",
  preferred_country: "USA",
  academic: "33",
  subject1: "Math",
  subject2: "Dance",
  subject3: "Physics",

  country_born: "China",
  current_country: "China",
  current_city: "Beijing",
  type_of_school: "International",
  secondary_qualification: "A-level",
  dream_career: "Dancer",

  artistic: "52",
  social: "30",
  investigative: "43",
  conventional: "33",
  enterprising: "20",
  realistic: "10",

  hedonism: "48",
  power_and_status: "39",
  altruism: "22",
  learning_and_achievement: "41",
  finance: "33",
  security: "37",

  q1: "50",
  q2: "20",
  q3: "40",

  father_education: "Master's",
  mother_education: "Master's",
  father_occupation: "Manager",
  mother_occupation: "Editor",
  annual_budget_usd: "30000",
  preferred_foe_1: "Dance",
  preferred_foe_2: "Arts",
  preferred_foe_3: "Management",
  notes: "Passionate about performing arts",
  concern: "Career stability",
  support: "Yes",

  // ✅ 新增 MBTI 评分字段（0–10）
  extrovert: 7,
  introvert: 3,
  sensing: 4,
  intuition: 6,
  thinking: 2,
  feeling: 8,
  judging: 6,
  perceiving: 4
};

export default mockProfile;
