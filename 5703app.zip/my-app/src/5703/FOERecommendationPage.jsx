import { useNavigate } from "react-router-dom";
import { useAdvisor } from "./context/AdvisorContext";

export default function FOERecommendationPage() {
  const navigate = useNavigate();
  const { output } = useAdvisor();

  if (!output || !output.recommendedFOE) {
    return <div style={{ padding: "2rem" }}>Loading recommendations...</div>;
  }

  const { recommendedFOE } = output;

  const cardStyle = {
    backgroundColor: "#ffffff",
    borderRadius: "0",
    padding: "1rem",
    boxShadow: "0 2px 6px rgba(0,0,0,0.1)",
    fontSize: "0.9rem",
    color: "#111",
    lineHeight: "1.6",
    overflowY: "auto",
    maxHeight: "240px"
  };

  const navCardStyle = {
    backgroundColor: "#031A47",
    padding: "0.6rem 0.9rem",
    borderRadius: "0",
    cursor: "pointer",
    fontWeight: "bold",
    fontSize: "0.9rem",
    color: "#fff",
    boxShadow: "0 2px 4px rgba(0, 0, 0, 0.08)"
  };

  const sectionHeader = (text) => (
    <div style={{
      display: "flex",
      alignItems: "center",
      backgroundColor: "#fff",
      padding: "0.4rem 1rem",
      borderBottom: "1px solid #eee",
      marginBottom: "0.25rem"
    }}>
      <div style={{
        width: "4px",
        height: "20px",
        backgroundColor: "#2563eb",
        marginRight: "0.5rem"
      }} />
      <h2 style={{
        fontSize: "1.4rem",
        fontWeight: 600,
        color: "#111",
        margin: 0
      }}>
        {text}
      </h2>
    </div>
  );

  return (
    <div style={{
      padding: "2rem 7rem",
      fontFamily: "Avenir Next, Arial, sans-serif",
      backgroundColor: "#031A47",
      minHeight: "100vh",
      boxSizing: "border-box",
      display: "flex",
      flexDirection: "column",
      gap: "1rem"
    }}>
      {sectionHeader("Recommended Field of Study")}

      {/* 第一推荐卡片 */}
      <div style={{ ...cardStyle }}>
        <h2 style={{ color: "#7c3aed", marginBottom: "0.5rem", marginTop: "0" }}>
          Top Recommendation: {recommendedFOE.title1.replace(/^\d+\s*/, "")}
        </h2>
        {recommendedFOE.paragraphs1.map((p, i) => (
          <p key={i}>{p}</p>
        ))}
      </div>






      {/* 第二、第三推荐卡片并排 */}
      <div style={{ display: "flex", gap: "1rem" }}>
        <div style={{ flex: 1, ...cardStyle }}>
        <h3 style={{ color: "#2563eb", marginBottom: "0.4rem", marginTop: "0" }}>
          Second Recommendation: {recommendedFOE.title2.replace(/^\d+\s*/, "")}
        </h3>
          {recommendedFOE.paragraphs2.map((p, i) => (
            <p key={i}>{p}</p>
          ))}
        </div>
        <div style={{ flex: 1, ...cardStyle }}>
        <h3 style={{ color: "#059669", marginBottom: "0.4rem", marginTop: "0" }}>
          Third Recommendation: {recommendedFOE.title3.replace(/^\d+\s*/, "")}
        </h3>   
          {recommendedFOE.paragraphs3.map((p, i) => (
            <p key={i}>{p}</p>
          ))}
        </div>
      </div>

      {/* 底部导航容器 */}
      <div style={{ backgroundColor: "#fff", borderRadius: "0", boxShadow: "0 2px 6px rgba(0,0,0,0.1)" }}>
        {sectionHeader("Navigation")}
        <div style={{ display: "flex", gap: "1rem", alignItems: "center", flexWrap: "wrap", padding: "1rem" }}>
          {[ 
            { text: "Recommended Field of Study", path: "/foe" },
            { text: "Suggested Universities and Majors", path: "/universities" },
            { text: "Next Step Guidance", path: "/guidance" }
          ].map((item, idx) => (
            <div
              key={idx}
              onClick={() => navigate(item.path)}
              style={navCardStyle}
            >
              {item.text}
            </div>
          ))}

          <button
            onClick={() => navigate("/form")}
            style={{
              backgroundColor: "#e0e0e0",
              color: "#fff",
              border: "none",
              padding: "0.6rem 1rem",
              borderRadius: "0",
              cursor: "pointer",
              fontWeight: "bold",
              fontSize: "0.9rem"
            }}
          >
            ← Back to Form
          </button>
        </div>
      </div>
    </div>
  );
}
