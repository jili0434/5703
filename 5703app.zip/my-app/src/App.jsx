import { HashRouter as Router, Routes, Route } from "react-router-dom";
import ResultLayout from "./5703/ResultLayout";
import FOERecommendationPage from "./5703/FOERecommendationPage";
import UniversityPage from "./5703/UniversityPage";
import GuidancePage from "./5703/GuidancePage";
import HomePage from "./5703/HomePage";
import LoadingPage from "./5703/LoadingPage";


function App() {
  return (
    <Router>
      <Routes>
        <Route path="/result" element={<ResultLayout />} />
        <Route path="/foe" element={<FOERecommendationPage />} />
        <Route path="/universities" element={<UniversityPage />} />
        <Route path="/guidance" element={<GuidancePage />} />
        <Route path="/" element={<HomePage />} />
        <Route path="/loading" element={<LoadingPage />} />
      </Routes>
    </Router>
  );
}

export default App;


