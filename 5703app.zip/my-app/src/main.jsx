import { StrictMode } from 'react';
import { createRoot } from 'react-dom/client';
import './index.css';
import App from './App.jsx';
import { AdvisorProvider } from './5703/context/AdvisorContext';

createRoot(document.getElementById('root')).render(
  <StrictMode>
    <AdvisorProvider>
      <App />
    </AdvisorProvider>
  </StrictMode>
);
