# from db_config import DBConfig
# from table_manager import create_tables_from_sql
# from data_loader import load_data_to_db
# from data_cleaner import (
#     clean_data_from_db,
#     preview_raw_data,
#     check_data_types,
#     check_missing_duplicates,
#     describe_cleaned_data,
#     standardize_and_clean_columns,
#     merge_all_tables,
#     drop_duplicates,
#     handle_merged_level_cleaning,
#     export_cleaned_data
# )
#
# def main():
#     # Step 1: Define database configuration
#     config = DBConfig(
#         name="",#"Daniel",
#         user="",#"postgres",
#         password="",#"localhost",
#         host="",#"localhost"
#         port="",#"5432"
#     )
#
#     # Step 2: Create tables using provided SQL script
#     with open("StudnetDatabase.sql", "r", encoding="utf-8") as f:
#         sql_script = f.read()
#     create_tables_from_sql(config, sql_script)
#
#     # Step 3: Load Excel data into database
#     load_data_to_db(config, "Survey_result_2025.xlsx")
#
#     # Step 4: Load and clean data from DB
#     dfs_raw, dfs_cleaned = clean_data_from_db(config)
#     preview_raw_data(dfs_raw)
#     check_data_types(dfs_cleaned)
#     check_missing_duplicates(dfs_cleaned)
#     describe_cleaned_data(dfs_cleaned)
#
#     # Step 5: Standardize all fields across tables
#     dfs_cleaned = standardize_and_clean_columns(dfs_cleaned)
#
#     # Step 6: Merge all tables and clean merged result
#     merged_df = merge_all_tables(dfs_cleaned)
#     merged_df = drop_duplicates(merged_df)
#     merged_df = handle_merged_level_cleaning(merged_df)
#
#     # Step 7: Export cleaned result
#     export_cleaned_data(merged_df, config)
#
# if __name__ == "__main__":
#     main()

import os
import pandas as pd
import random
from openai import OpenAI

# Load OpenAI API key securely, fallback to manual override (only for testing)
api_key = os.getenv("OPENAI_API_KEY") or "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"
client = OpenAI(api_key=api_key)

def validate_api_key():
    try:
        client.models.list()
        print("✅ OpenAI API key is valid.")
    except Exception as e:
        print("❌ Invalid API Key:", e)

def generate_custom_prompt_response(system_prompt: str, user_prompt: str) -> str:
    """
    Generate a response from OpenAI with a customizable system prompt (used to define role/behavior)
    and a user prompt (e.g., from dataset input).
    """
    if not client.api_key:
        return "Error: OPENAI_API_KEY is not set or invalid."

    try:
        response = client.chat.completions.create(
            model="gpt-3.5-turbo",
            messages=[
                {"role": "system", "content": system_prompt.strip()},
                {"role": "user", "content": user_prompt.strip()}
            ]
        )
        return response.choices[0].message.content.strip()
    except Exception as e:
        return f"An error occurred while contacting OpenAI: {str(e)}"

def load_random_user_prompt(file_path: str) -> str:
    """Load a random user sample from a CSV file and return as string."""
    try:
        df = pd.read_csv(file_path)
        random_row = df.sample(n=1).iloc[0]
        user_input = str(random_row.to_dict())
        print("\nSelected random sample as user prompt:")
        print(user_input)
        return user_input
    except Exception as e:
        print("Error loading data:", e)
        return input("Enter user prompt manually (fallback): ")

def get_unique_filename(base_filename: str) -> str:
    """Generate a unique filename by appending a number if the file exists."""
    if not os.path.exists(base_filename):
        return base_filename

    base, ext = os.path.splitext(base_filename)
    counter = 1
    while True:
        new_filename = f"{base}_{counter}{ext}"
        if not os.path.exists(new_filename):
            return new_filename
        counter += 1

def write_response_to_file(user_prompt: str, response: str, file_path: str = "response_output.txt"):
    """Write user prompt and GPT response to a text file with automatic renaming if file exists."""
    file_path = get_unique_filename(file_path)
    with open(file_path, "w", encoding="utf-8") as f:
        f.write("Selected user prompt:\n")
        f.write(user_prompt + "\n\n")
        f.write("GPT Response:\n")
        f.write(response)
    print(f"\n✅ Output written to '{file_path}'")

# Optional direct run
if __name__ == "__main__":
    validate_api_key()
    system_input = (
        "You are an experienced career counselor. Based on a student's demographics, "
        "personality, education, values, MBTI type, and preferences, provide tailored "
        "and practical career guidance. Your suggestions should consider their interests, "
        "cultural background, and budget. Present the advice in a clear, encouraging, and structured format."
    )
    user_input = load_random_user_prompt("cleaned_full_data.csv")
    result = generate_custom_prompt_response(system_input, user_input)
    print("\nResponse:\n", result)
    write_response_to_file(user_input, result)