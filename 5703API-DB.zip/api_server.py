import os
import pandas as pd
import random
from openai import OpenAI

# Load OpenAI API key securely, fallback to manual override (only for testing)
api_key = os.getenv("OPENAI_API_KEY") or "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"
client = OpenAI(api_key=api_key)

def validate_api_key():
    try:
        client.models.list()
        print("✅ OpenAI API key is valid.")
    except Exception as e:
        print("❌ Invalid API Key:", e)

def generate_custom_prompt_response(system_prompt: str, user_prompt: str) -> str:
    """
    Generate a response from OpenAI with a customizable system prompt (used to define role/behavior)
    and a user prompt (e.g., from dataset input).
    """
    if not client.api_key:
        return "Error: OPENAI_API_KEY is not set or invalid."

    try:
        response = client.chat.completions.create(
            model="gpt-3.5-turbo",
            messages=[
                {"role": "system", "content": system_prompt.strip()},
                {"role": "user", "content": user_prompt.strip()}
            ]
        )
        return response.choices[0].message.content.strip()
    except Exception as e:
        return f"An error occurred while contacting OpenAI: {str(e)}"

def load_random_user_prompt(file_path: str) -> str:
    """Load a random user sample from a CSV file and return as string."""
    try:
        df = pd.read_csv(file_path)
        random_row = df.sample(n=1).iloc[0]
        user_input = str(random_row.to_dict())
        print("\nSelected random sample as user prompt:")
        print(user_input)
        return user_input
    except Exception as e:
        print("Error loading data:", e)
        return input("Enter user prompt manually (fallback): ")

def write_response_to_file(user_prompt: str, response: str, file_path: str = "response_output.txt"):
    """Write user prompt and GPT response to a text file."""
    with open(file_path, "w", encoding="utf-8") as f:
        f.write("Selected user prompt:\n")
        f.write(user_prompt + "\n\n")
        f.write("GPT Response:\n")
        f.write(response)
    print(f"\n✅ Output written to '{file_path}'")

# Optional direct run
if __name__ == "__main__":
    validate_api_key()
    system_input = (
        "You are an experienced career counselor. Based on a student's demographics, "
        "personality, education, values, MBTI type, and preferences, provide tailored "
        "and practical career guidance. Your suggestions should consider their interests, "
        "cultural background, and budget. Present the advice in a clear, encouraging, and structured format."
    )
    user_input = load_random_user_prompt("cleaned_full_data.csv")
    result = generate_custom_prompt_response(system_input, user_input)
    print("\nResponse:\n", result)
    write_response_to_file(user_input, result)
