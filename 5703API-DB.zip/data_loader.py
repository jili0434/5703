import pandas as pd
from db_config import get_connection

def load_data_to_db(config, excel_path):
    conn = get_connection(config)
    cur = conn.cursor()

    table_sheet_info = {
        "students": "Section0",
        "values": "Section 1 - Value",
        "career_orientation": "Section2 - Career Orientation",
        "personality": "Section 3 - Personality",
        "creative_thinking": "Section 4 - creativity thinking",
        "family_info": "Section 5 - Family"
    }

    xlsx = pd.ExcelFile(excel_path)

    for table_name, sheet_name in table_sheet_info.items():
        df = xlsx.parse(sheet_name)
        records = df.values.tolist()
        placeholders = ', '.join(['%s'] * df.shape[1])
        insert_sql = f'INSERT INTO {table_name} VALUES ({placeholders})'
        cur.execute(f"DELETE FROM {table_name}")
        cur.executemany(insert_sql, records)
        print(f"Inserted {len(records)} records into {table_name}")

    conn.commit()
    cur.close()
    conn.close()