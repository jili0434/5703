
# 5703 Data Cleaning & Integration Pipeline

## 📌 Overview

This project builds a complete data preparation pipeline that:
- Creates PostgreSQL tables
- Loads multi-sheet Excel survey data
- Cleans, standardizes, and merges all datasets
- Handles missing values, formatting issues, and inconsistencies
- Saves the final result to CSV, Excel, and back to PostgreSQL

---

## 🧱 Project Structure

```
├── db_config.py              # Database credentials & connection logic
├── table_manager.py          # SQL-based table creation
├── data_loader.py            # Excel-to-PostgreSQL importer
├── data_cleaner_optimized.py # Full pipeline of cleaning, merging, exporting
├── main_optimized.py         # Main script orchestrating all steps
├── Survey_result_2025.xlsx   # Source Excel file
├── StudnetDatabase.sql       # Table schema script
└── cleaned_full_data.csv     # Final cleaned result (output)
```

---

## 🔧 How to Run

1. Install dependencies:
```bash
pip install pandas sqlalchemy psycopg2 openpyxl
```

2. Place the following input files in the root directory:
   - `Survey_result_2025.xlsx`
   - `StudnetDatabase.sql`

3. Run the script:
```bash
python main.py
```

---

## 📤 Output

You will get:
- `cleaned_full_data.csv`
- `cleaned_full_data.xlsx`
- A new SQL table `cleaned_full_data` written to your PostgreSQL DB

---

## 📌 Notes

- All `null`, `"NA"`, `"na"`, `"NaN"`, `""` are replaced with `pd.NA`
- `MBTI` types are inferred if missing
- Budget values with missing entries are filled with 1.1 × max
- Consistent text encoding applied to fields like language, gender, qualification

---
