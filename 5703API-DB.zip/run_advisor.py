from api_server import (
    validate_api_key,
    load_random_user_prompt,
    generate_custom_prompt_response,
    write_response_to_file
)

def main():
    validate_api_key()

    system_prompt = (
        "You are an experienced career counselor. Based on a student's demographics, "
        "personality, education, values, MBTI type, and preferences, provide tailored "
        "and practical career guidance. Your suggestions should consider their interests, "
        "cultural background, and budget. Present the advice in a clear, encouraging, and structured format."
    )

    user_prompt = load_random_user_prompt("cleaned_full_data.csv")
    response = generate_custom_prompt_response(system_prompt, user_prompt)
    print("\nResponse:\n", response)
    write_response_to_file(user_prompt, response)

if __name__ == "__main__":
    main()