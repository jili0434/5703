// src/5703/HomePage.jsx
import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { useAdvisor } from "./context/AdvisorContext";

export default function HomePage() {
  const [identifier, setIdentifier] = useState("");
  const { setProfile, setOutput, setProgressStep } = useAdvisor();
  const navigate = useNavigate();

  const handleSubmit = async (e) => {
    e.preventDefault();

    if (!identifier) {
      alert("Please enter your identifier.");
      return;
    }

    try {
      const response = await fetch(`http://localhost:8000/api/get_profile?identifier=${identifier}`);
      const data = await response.json();

      if (data.error) {
        alert("Identifier not found. Please try again.");
        // 自动返回主页，清空 ID 输入框
        setIdentifier("");
        return;
      }

      console.log("✅ Received profile:", data);

      // 存入 context
      setProfile(data);
      localStorage.setItem("profile", JSON.stringify(data));

      // 重置进度（如果之前有）
      setProgressStep(0);
      setOutput(null);

      // 跳转 loading 页面，后续流程自己触发 analyze
      navigate("/loading");
    } catch (error) {
      console.error(error);
      alert("Failed to connect to server.");
    }
  };


  return (
    <div style={sectionStyle}>
      <form onSubmit={handleSubmit} style={cardStyle}>
        <h2 style={titleStyle}>Enter Your Identifier</h2>
        <input
          type="text"
          value={identifier}
          onChange={(e) => setIdentifier(e.target.value)}
          placeholder="Enter your ID"
          style={inputStyle}
        />
        <button type="submit" style={nextButtonStyle}>
          Submit →
        </button>
      </form>
    </div>
  );
}

const inputStyle = {
  padding: "0.75rem",
  border: "1px solid #d1d5db",
  borderRadius: "0",
  fontSize: "1rem",
  backgroundColor: "#ffffff",
  color: "#111827",
  boxShadow: "0 1px 2px rgba(0,0,0,0.04)",
  lineHeight: "1.2",
  width: "100%",
  marginBottom: "1rem"
};

const cardStyle = {
  width: "100%",
  maxWidth: "500px",
  display: "flex",
  flexDirection: "column",
  gap: "1rem",
  backgroundColor: "#ffffff",
  padding: "2rem",
  borderRadius: "0",
  boxShadow: "0 4px 12px rgba(0,0,0,0.1)"
};

const nextButtonStyle = {
  padding: "0.8rem 1.5rem",
  backgroundColor: "#EB2B4A",
  color: "#ffffff",
  fontWeight: "bold",
  border: "none",
  borderRadius: "0",
  cursor: "pointer"
};

const titleStyle = {
  fontSize: "2rem",
  fontWeight: "600",
  color: "#111827",
  marginBottom: "1rem"
};

const sectionStyle = {
  position: "fixed",
  top: 0,
  left: 0,
  width: "100vw",
  height: "100vh",
  display: "flex",
  justifyContent: "center",
  alignItems: "center",
  backgroundColor: "#031A47",
  padding: "2rem",
  boxSizing: "border-box",
  fontFamily: "'Segoe UI', 'Helvetica Neue', sans-serif"
};
