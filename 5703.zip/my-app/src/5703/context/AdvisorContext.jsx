import { createContext, useContext, useState } from "react";

// 所有字段初始值（可用于清空/初始化）
const initialProfile = {
  // Basic Info
  first_letter_surname: "",
  age: "",
  gender: "",
  first_language: "",
  other_language: "",
  preferred_country: "",
  academic: "",
  subject1: "",
  subject2: "",
  subject3: "",

  // Background
  country_born: "",
  current_country: "",
  current_city: "",
  type_of_school: "",
  secondary_qualification: "",
  dream_career: "",

  // Career Interests
  artistic: "",
  social: "",
  investigative: "",
  conventional: "",
  enterprising: "",
  realistic: "",

  // Core Values
  hedonism: "",
  power_and_status: "",
  altruism: "",
  learning_and_achievement: "",
  finance: "",
  security: "",

  // Scenario Scores
  q1: "",
  q2: "",
  q3: "",

  // Family & Planning
  father_education: "",
  mother_education: "",
  father_occupation: "",
  mother_occupation: "",
  annual_budget_usd: "",
  preferred_foe_1: "",
  preferred_foe_2: "",
  preferred_foe_3: "",
  notes: "",
  concern: "",
  support: "",

  // MBTI (optional default)
  extrovert: "", introvert: "",
  sensing: "", intuition_n: "",
  thinking: "", feeling: "",
  judging: "", perceiving: ""
};

// ✅ 声明 Context
const AdvisorContext = createContext();

// ✅ 提供 Provider 包裹 App
export function AdvisorProvider({ children }) {
  const [profile, setProfile] = useState(initialProfile);
  const [output, setOutput] = useState(null);
  const [progressStep, setProgressStep] = useState(0);  // 替代原先的 progress 文本

  return (
    <AdvisorContext.Provider value={{
      profile,
      setProfile,
      output,
      setOutput,
      progressStep,
      setProgressStep
    }}>
      {children}
    </AdvisorContext.Provider>
  );
}

// ✅ 导出自定义 Hook：其它组件用它访问 context
export function useAdvisor() {
  return useContext(AdvisorContext);
}
