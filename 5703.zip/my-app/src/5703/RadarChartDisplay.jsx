import { Radar, RadarChart, PolarGrid, PolarAngleAxis, PolarRadiusAxis, ResponsiveContainer } from "recharts";
import { useAdvisor } from "./context/AdvisorContext";

export default function RadarChartDisplay({ type }) {
  const { profile } = useAdvisor();

  const traits = type === "career"
    ? ["artistic", "social", "investigative", "conventional", "enterprising", "realistic"]
    : ["hedonism", "power_and_status", "altruism", "learning_and_achievement", "finance", "security"];

  const data = traits.map((key) => ({
    subject: key.replace(/_/g, " ").replace(/\b\w/g, l => l.toUpperCase()),
    score: Number(profile[key]) || 0,
  }));

  const stroke = type === "career" ? "#8884d8" : "#82ca9d";

  return (
    <ResponsiveContainer width="100%" height="100%">
      <RadarChart data={data}>
        <PolarGrid />
        <PolarAngleAxis dataKey="subject" />
        <PolarRadiusAxis angle={30} domain={[0, 60]} />
        <Radar name="score" dataKey="score" stroke={stroke} fill={stroke} fillOpacity={0.6} />
      </RadarChart>
    </ResponsiveContainer>
  );
}
