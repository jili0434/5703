import { useNavigate } from "react-router-dom";
import { navItems } from "./frontendContent";
import { useAdvisor } from "./context/AdvisorContext";
import RadarChartDisplay from "./RadarChartDisplay";

export default function ResultLayout() {
  const navigate = useNavigate();
  const { output, profile } = useAdvisor();

  const handleBackToForm = () => {
    window.location.href = "/";
  };
  
  if (!output || !output.summaryAnalysisText) {
    return <div style={{ padding: "0.1 rem" }}>Loading summary...</div>;
  }

  const mbtiPairs = [
    ["Extrovert", "Introvert"],
    ["Sensing", "Intuition"],
    ["Thinking", "Feeling"],
    ["Judging", "Perceiving"]
  ];

  const renderMBTIBars = () => (
    <div style={{ display: "flex", flexDirection: "column", gap: "0.3rem" }}>
      {mbtiPairs.map(([left, right]) => {
        const leftScore = Number(profile[left.toLowerCase()]) || 0;
        const rightScore = Number(profile[right.toLowerCase()]) || 0;
        const total = leftScore + rightScore || 1;
        const leftPercent = (leftScore / total) * 100;
        const rightPercent = 100 - leftPercent;

        return (
          <div key={left}>
            <div style={{ display: "flex", justifyContent: "space-between", fontSize: "0.85rem", marginBottom: "0.2rem" }}>
              <span>{left}</span>
              <span>{right}</span>
            </div>
            <div style={{ display: "flex", height: "12px", borderRadius: "0", overflow: "hidden", backgroundColor: "#ddd" }}>
              <div style={{ width: `${leftPercent}%`, backgroundColor: "#3b82f6" }}></div>
              <div style={{ width: `${rightPercent}%`, backgroundColor: "#f87171" }}></div>
            </div>
          </div>
        );
      })}
    </div>
  );

  const sectionHeader = (text) => (
    <div style={{
      display: "flex",
      alignItems: "center",
      backgroundColor: "#fff",
      padding: "0.4rem 1rem",
      borderBottom: "1px solid #eee",
      marginBottom: "0.25rem"
    }}>
      <div style={{
        width: "4px",
        height: "20px",
        backgroundColor: "#2563eb",
        marginRight: "0.5rem"
      }} />
      <h2 style={{
        fontSize: "1.4rem",
        fontWeight: 600,
        color: "#111",
        margin: 0
      }}>
        {text}
      </h2>
    </div>
  );

  return (
    <div style={{
      position: "fixed",
      top: 0,
      left: 0,
      width: "100vw",
      height: "100vh",
      display: "flex",
      justifyContent: "center",
      alignItems: "center",
      backgroundColor: "#031A47",
      padding: "2rem 7rem",
      boxSizing: "border-box"
    }}>
      <div style={{
        width: "100%",
        maxWidth: "1200px",
        height: "100%",
        display: "flex",
        gap: "2rem",
        fontFamily: "Arial, sans-serif",
        fontSize: "0.9rem",
        color: "#222",
        lineHeight: "1.5"
      }}>
        {/* 左侧 */}
        <div style={{ flex: 2, display: "flex", flexDirection: "column", justifyContent: "space-between" }}>
          {/* 分析说明卡片 */}
          <div style={{
            backgroundColor: "#fff",
            borderRadius: "0",
            boxShadow: "0 2px 6px rgba(0,0,0,0.1)",
            height: "70%",
            overflowY: "auto"
          }}>
            {sectionHeader("Summary of Analysis")}
            <div style={{ padding: "1rem" }}>
              {output.summaryAnalysisText
                .replace(/\\n/g, '\n') // 先把字面字符 \n 转成真实换行符
                .split(/\n+/)
                .map(para => para.trim())
                .filter(para => para.length > 0)
                .map((para, i) => (
                  <p key={i}>{para}</p>
              ))}

            </div>
          </div>

          {/* 三宫格导航（点击跳转） */}
          <div style={{
            marginTop: "1rem",
            backgroundColor: "#ffffff",
            borderRadius: "0",
            boxShadow: "0 2px 6px rgba(0,0,0,0.1)"
          }}>
            {sectionHeader("Navigation")}
            <div style={{ padding: "1rem" }}>
              <div style={{
                display: "grid",
                gridTemplateColumns: "1fr 1fr 1fr",
                gap: "1rem",
                padding: "0 1rem",
                marginBottom: "1rem"
              }}>
                {navItems.slice(1).map((item, idx) => (
                  <div
                    key={idx}
                    onClick={() => navigate(item.path)}
                    style={cardStyle()}
                  >
                    {item.text}
                  </div>
                ))}
              </div>

              {/* 返回按钮 */}
              <div style={{ textAlign: "center" }}>
                <button
                  onClick={handleBackToForm}
                  style={{
                    backgroundColor: "#e0e0e0",
                    border: "none",
                    padding: "0.5rem 1rem",
                    borderRadius: "0",
                    cursor: "pointer",
                    fontWeight: "bold"
                  }}
                >
                  ← Back to Form
                </button>
              </div>
            </div>
          </div>
        </div>

        {/* 右侧：图表 */}
        <div style={{ flex: 1, display: "flex", flexDirection: "column", gap: "1rem" }}>
          <div style={{ ...cardBox, height: "240px" }}>
            {sectionHeader("Career Interest Scores")}
            <div style={{ width: "100%", height: "200px" }}>
              <RadarChartDisplay type="career" />
            </div>
          </div>
          <div style={{ ...cardBox, height: "240px" }}>
            {sectionHeader("Core Value Scores")}
            <div style={{ width: "100%", height: "200px" }}>
              <RadarChartDisplay type="value" />
            </div>
          </div>
          <div style={{ ...cardBox, height: "230px" }}>
            {sectionHeader("Simplified MBTI")}
            <div style={{ padding: "0.75rem 1rem" }}>{renderMBTIBars()}</div>
          </div>
        </div>
      </div>
    </div>
  );
}

const cardBox = {
  backgroundColor: "#fff",
  borderRadius: "0",
  padding: "0",
  boxShadow: "0 2px 6px rgba(0,0,0,0.1)"
};

function cardStyle() {
  return {
    backgroundColor: "#031A47",
    padding: "0.75rem",
    borderRadius: "0",
    textAlign: "center",
    cursor: "pointer",
    fontWeight: "bold",
    transition: "all 0.2s ease-in-out",
    boxShadow: "0 2px 4px rgba(0, 0, 0, 0.1)",
    userSelect: "none",
    color: "#fff"
  };
}
