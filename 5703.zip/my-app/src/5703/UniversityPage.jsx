import { useNavigate } from "react-router-dom";
import { useAdvisor } from "./context/AdvisorContext";

export default function UniversityPage() {
  const navigate = useNavigate();
  const { output } = useAdvisor();

  if (!output || !output.universityRecommendations) {
    return <div style={{ padding: "2rem" }}>Loading recommendations...</div>;
  }

  const universities = output.universityRecommendations;

  const rowStyle = {
    borderBottom: "1px solid #ddd"
  };

  const labelCell = {
    fontWeight: "bold",
    paddingRight: "1rem",
    verticalAlign: "top",
    width: "160px",
    whiteSpace: "nowrap",
    paddingBottom: "0.3rem"
  };

  const cardStyle = {
    backgroundColor: "#ffffff",
    borderRadius: "0",
    padding: "1.25rem",
    boxShadow: "0 2px 6px rgba(0,0,0,0.1)",
    fontSize: "0.9rem",
    color: "#111",
    lineHeight: "1.6",
    overflowY: "auto",
    maxHeight: "320px",
    minWidth: "320px",
    height: "340px",
    boxSizing: "border-box"
  };

  const navCardStyle = {
    backgroundColor: "#031A47",
    padding: "0.6rem 0.9rem",
    borderRadius: "0",
    cursor: "pointer",
    fontWeight: "bold",
    fontSize: "0.9rem",
    color: "#fff",
    boxShadow: "0 2px 4px rgba(0, 0, 0, 0.08)"
  };

  const sectionHeader = (text) => (
    <div style={{
      display: "flex",
      alignItems: "center",
      backgroundColor: "#fff",
      padding: "0.4rem 1rem",
      borderBottom: "1px solid #eee",
      marginBottom: "0.25rem"
    }}>
      <div style={{
        width: "4px",
        height: "20px",
        backgroundColor: "#2563eb",
        marginRight: "0.5rem"
      }} />
      <h2 style={{
        fontSize: "1.4rem",
        fontWeight: 600,
        color: "#111",
        margin: 0
      }}>
        {text}
      </h2>
    </div>
  );

  return (
    <div style={{
      width: "100vw",
      minHeight: "100vh",
      backgroundColor: "#031A47",
      fontFamily: "Avenir Next, Arial, sans-serif",
      boxSizing: "border-box",
      padding: "2rem 7rem",
      display: "flex",
      flexDirection: "column",
      justifyContent: "space-between"
    }}>
      <div style={{
        maxWidth: "1200px",
        margin: "0 auto",
        display: "flex",
        flexDirection: "column",
        gap: "1.5rem"
      }}>
        {sectionHeader("Suggested Universities and Majors")}

        <div style={{
          display: "grid",
          gridTemplateColumns: "repeat(3, 1fr)",
          gap: "1.5rem",
          justifyContent: "center"
        }}>
          {universities.map((item, idx) => (
            <div key={idx} style={cardStyle}>
              <h3 style={{ fontWeight: "bold", marginBottom: "0.75rem" }}>
                Recommendation {idx + 1}
              </h3>
              <table style={{ width: "100%", borderCollapse: "collapse" }}>
                <tbody>
                  <tr style={rowStyle}><td style={labelCell}>Recommended University</td><td>{item.university?.replace(/^"|"$/g, '')}</td></tr>
                  <tr style={rowStyle}><td style={labelCell}>Recommended Major</td><td>{item.major?.replace(/^"|"$/g, '')}</td></tr>
                  <tr style={rowStyle}><td style={labelCell}>Note</td><td>{item.note?.replace(/^"|"$/g, '')}</td></tr>
                  <tr style={rowStyle}><td style={labelCell}>Academic Exam</td><td>{item.exam?.replace(/^"|"$/g, '')}</td></tr>
                  <tr style={rowStyle}><td style={labelCell}>Required Score</td><td>{item.score?.replace(/^"|"$/g, '')}</td></tr>
                  <tr style={rowStyle}><td style={labelCell}>Special Requirements</td><td>{item.special?.replace(/^"|"$/g, '')}</td></tr>
                </tbody>
              </table>
            </div>
          ))}

          {/* Navigation card appended to grid */}
          <div style={cardStyle}>
            {sectionHeader("Navigation")}
            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "1rem" }}>
              {[ 
                { text: "Personal information analysis", path: "/result" },
                { text: "Recommended Field of Study", path: "/foe" },
                { text: "Next Step Guidance", path: "/guidance" }
              ].map((item, idx) => (
                <div
                  key={idx}
                  onClick={() => navigate(item.path)}
                  style={navCardStyle}
                >
                  {item.text}
                </div>
              ))}

              <button
                onClick={() => navigate("/")}
                style={{
                  backgroundColor: "#e0e0e0",
                  color: "#fff",
                  border: "none",
                  padding: "0.6rem 1rem",
                  borderRadius: "0",
                  cursor: "pointer",
                  fontWeight: "bold",
                  fontSize: "0.9rem"
                }}
              >
                ← Back to Form
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
