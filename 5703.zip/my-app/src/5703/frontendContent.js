// 所有页面共用的静态变量内容集中管理

// 首页 - 分析文本
export const summaryAnalysisText = `
Based on this student's characteristics, there is a significant emphasis on artistic interests, creative expression, and a tendency towards social interaction. Their dream career is to become an artist, and the scores reflect a strong affinity for creativity (Artistic score of 50), alongside a commendable sense of social awareness which can enhance their artistic endeavors. This student also shows notable strengths in investigative skills, indicating an ability to analyze various artistic contexts and trends, which can be valuable in their pursuit of an art career.

From a core values perspective, the student values hedonism (45) suggesting that they prioritize personal enjoyment and aesthetic pleasure in their activities, underscoring their desire to engage in artistic expression. Their lower scores in security (5) and finance (25) suggest that they may not be primarily driven by economic or stability concerns but rather seek fulfillment through creative endeavors.

Additionally, as an ESFP personality type, they are typically lively, enthusiastic, and enjoy engaging with others, making them suitable for collaborative artistic environments. However, their low scores in areas such as learning and achievement (10) may indicate a lesser interest in traditional academic rigor which could present challenges if pursuing a more structured art discipline.

In summary, while the student's aspirations align well with their artistic strengths and values, considerations for practicality in building a stable career in the arts should be made, particularly regarding financial and job security.
`;

// FOE 推荐页面内容（三段）
export const recommendedFOE = {
  title1: "1003 Performing Arts",
  paragraphs1: [
    "After in-depth analysis of this student's characteristics, my top recommended specific direction is: 1003 Performing Arts. This field includes training in dance, theater, and music, aligning directly with her dream of 'becoming a dancer'.",
    "This student has significant potential within the performing arts realm...",
    "From a personality perspective, as an INFP...",
    "Additionally, her value on power and status...",
    "Considering her advanced education background...",
    "Qualification recommendation: The ideal qualification level is a bachelor's degree."
  ],
  title2: "0909 Arts Management",
  paragraphs2: [
    "This integrates both her artistic interests and her high conventional and enterprising scores.",
    "Students in this field often learn about the business aspects of the arts...",
    "Her INFP tendencies could enrich her approach...",
    "Qualification recommendation: Bachelor's degree with internships."
  ],
  title3: "1005 Dance",
  paragraphs3: [
    "The proposed area directly relates to 1005 Dance...",
    "Her significant artistic inclination...",
    "Additionally, her artistic and feeling scores...",
    "Qualification recommendation: Bachelor's degree in performance or pedagogy."
  ]
};

// 大学推荐信息（用于表格，添加编号变量名）
export const universityRecommendation1 = {
  university: "New York University (NYU)",
  major: "Bachelor of Fine Arts in Dance",
  note: "Comprehensive curriculum combining performance, choreography, and movement.",
  exam: "International Baccalaureate",
  score: "31.0/45 (68.89/100)",
  special: "Audition and video required."
};

export const universityRecommendation2 = {
  university: "University of Pennsylvania",
  major: "Bachelor of Arts in Theater Arts",
  note: "Interdisciplinary program integrating performance, dance, and drama.",
  exam: "International Baccalaureate",
  score: "33.0/45 (73.33/100)",
  special: "Audition and artistic statement required."
};

export const universityRecommendation3 = {
  university: "California Institute of the Arts (CalArts)",
  major: "Bachelor of Fine Arts in Dance",
  note: "Focuses on creation of new work and dance philosophies.",
  exam: "International Baccalaureate",
  score: "Not specified",
  special: "Audition and portfolio required."
};

export const universityRecommendation4 = {
  university: "Boston University",
  major: "Bachelor of Fine Arts in Theater Arts",
  note: "Practical performance and creative work focused curriculum.",
  exam: "International Baccalaureate",
  score: "30.0/45 (66.67/100)",
  special: "Audition showcasing full theatrical range required."
};

export const universityRecommendation5 = {
  university: "University of Southern California (USC)",
  major: "Bachelor of Fine Arts in Dance",
  note: "Strong academic and experiential focus on dance as art.",
  exam: "International Baccalaureate",
  score: "32.0/45 (71.11/100)",
  special: "Audition required with proficiency in dance styles."
};

export const universityRecommendations = [
  universityRecommendation1,
  universityRecommendation2,
  universityRecommendation3,
  universityRecommendation4,
  universityRecommendation5
];

// 第四页正文文本（整体一段）
export const guidanceParagraph = `
While pursuing a career as a dancer is a wonderful dream aligned with her artistic inclinations, based on her interest scores, particularly her high investigative and conventional traits, it may be beneficial for her to also consider backing her dance aspiration with skills in arts management or choreography. The formal dance environment can often be competitive, so developing further strategies for enhancing her visibility and career opportunities is advisable.

Joining local dance groups, taking part in showcases, or enrolling in diverse dance workshops could elevate her experience and allow her to network with others in the industry. Furthermore, she should consider enhancing her understanding of the business side of dance, which could mitigate potential instability in a performance-focused career.

To solidify her position in the arts, looking into volunteer positions or internships in arts management may provide practical experience and help establish useful connections in the industry. It's essential for her to maintain an open mind and explore various channels through which her love for dance can manifest, allowing for a diversified career path that could lead through performance, management, or education.
`;
export const navItems = [
  { text: "Personal information analysis", path: "/", bg: "#d0ebff" },
  { text: "Recommended Field of Study", path: "/foe", bg: "#ffe3e3" },
  { text: "Suggested Universities and Majors", path: "/universities", bg: "#fff9db" },
  { text: "Next Step Guidance", path: "/guidance", bg: "#e6fcf5" }
];
