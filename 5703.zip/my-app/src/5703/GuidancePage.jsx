import { useNavigate } from "react-router-dom";
import { useAdvisor } from "./context/AdvisorContext";

export default function GuidancePage() {
  const navigate = useNavigate();
  const { output } = useAdvisor();

  if (!output || !output.guidanceParagraph) {
    return <div style={{ padding: "2rem" }}>Loading guidance...</div>;
  }

  const contentCardStyle = {
  backgroundColor: "#ffffff",
  borderRadius: "0",
  padding: "1.25rem",
  boxShadow: "0 2px 6px rgba(0,0,0,0.1)",
  fontSize: "0.9rem",
  color: "#111",
  lineHeight: "1.6",
  overflowY: "auto",
  minHeight: "340px",
  boxSizing: "border-box",
  whiteSpace: "pre-wrap"
};

const navCardContainerStyle = {
  backgroundColor: "#ffffff",
  borderRadius: "0",
  padding: "1.25rem",
  boxShadow: "0 2px 6px rgba(0,0,0,0.1)",
  boxSizing: "border-box"
};

  const navCardStyle = {
    backgroundColor: "#031A47",
    padding: "0.6rem 0.9rem",
    borderRadius: "0",
    cursor: "pointer",
    fontWeight: "bold",
    fontSize: "0.9rem",
    color: "#fff",
    boxShadow: "0 2px 4px rgba(0, 0, 0, 0.08)"
  };

  const sectionHeader = (text) => (
    <div style={{
      display: "flex",
      alignItems: "center",
      backgroundColor: "#fff",
      padding: "0.4rem 1rem",
      borderBottom: "1px solid #eee",
      marginBottom: "0.25rem"
    }}>
      <div style={{
        width: "4px",
        height: "20px",
        backgroundColor: "#2563eb",
        marginRight: "0.5rem"
      }} />
      <h2 style={{
        fontSize: "1.4rem",
        fontWeight: 600,
        color: "#111",
        margin: 0
      }}>
        {text}
      </h2>
    </div>
  );

  return (
    <div style={{
      width: "100vw",
      minHeight: "100vh",
      backgroundColor: "#031A47",
      fontFamily: "Avenir Next, Arial, sans-serif",
      boxSizing: "border-box",
      padding: "2rem 7rem",
      display: "flex",
      flexDirection: "column",
      justifyContent: "flex-start"
    }}>
      <div style={{
        maxWidth: "1200px",
        margin: "0 auto",
        display: "flex",
        flexDirection: "column",
        gap: "1.5rem"
      }}>
        {sectionHeader("Next Step Guidance")}

        {/* Guidance card */}
        <div style={contentCardStyle}>
          {output.guidanceParagraph}
        </div>

        {/* Navigation embedded card */}
        <div style={navCardContainerStyle}>
          {sectionHeader("Navigation")}
          <div style={{
            display: "flex", flexWrap: "wrap", justifyContent: "flex-start",
            gap: "1rem"
          }}>
            {[ 
              { text: "Personal information analysis", path: "/result" },
              { text: "Recommended Field of Study", path: "/foe" },
              { text: "Suggested Universities and Majors", path: "/universities" }
            ].map((item, idx) => (
              <div
                key={idx}
                onClick={() => navigate(item.path)}
                style={{ ...navCardStyle, width: "auto" }}
              >
                {item.text}
              </div>
            ))}

            <button
              onClick={() => navigate("/")}
              style={{
                backgroundColor: "#e0e0e0",
                color: "#fff",
                border: "none",
                padding: "0.6rem 1rem",
                borderRadius: "0",
                cursor: "pointer",
                fontWeight: "bold",
                fontSize: "0.9rem"
              }}
            >
              ← Back to Form
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
