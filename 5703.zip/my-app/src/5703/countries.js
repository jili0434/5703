const countries = [
  "United States", "United Kingdom", "Canada", "Australia", "Germany", "Netherlands",
  "Singapore", "France", "New Zealand", "Japan", "South Korea", "Other"
];

export default countries;