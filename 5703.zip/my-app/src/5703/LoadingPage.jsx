import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { useAdvisor } from "./context/AdvisorContext";

const steps = [
  "🔑 Validating API Key",
  "📄 Reading prompt template",
  "🧠 Generating FOE recommendation",
  "✅ FOE recommendation completed",
  "🎯 Loading university prompt",
  "🏫 Generating university matches",
  "📊 Final result parsing",
];

function SpinnerSVG() {
  return (
    <svg
      width="40"
      height="40"
      viewBox="0 0 50 50"
      style={{ display: 'block', margin: '0 auto' }}
    >
      <circle
        cx="25"
        cy="25"
        r="20"
        fill="none"
        stroke="#2563eb"
        strokeWidth="5"
        strokeLinecap="round"
        strokeDasharray="100"
        strokeDashoffset="60"
      >
        <animateTransform
          attributeName="transform"
          type="rotate"
          from="0 25 25"
          to="360 25 25"
          dur="1s"
          repeatCount="indefinite"
        />
      </circle>
    </svg>
  );
}

export default function LoadingPage() {
  const { setOutput } = useAdvisor();
  const navigate = useNavigate();
  const [stepIndex, setStepIndex] = useState(0);

  useEffect(() => {
    const fetchAnalysis = async () => {
      const profile = JSON.parse(localStorage.getItem("profile"));
      if (!profile) {
        alert("No profile found.");
        navigate("/");
        return;
      }

      try {
        console.log("🚀 Sending profile to /api/analyze:", profile);

        const response = await fetch("http://localhost:8000/api/analyze", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(profile)
        });

        const result = await response.json();
        console.log("✅ Received analysis result:", result);

      setOutput({
        recommendedFOE: result.recommendedFOE,
        universityRecommendations: result.universityRecommendations,
        guidanceParagraph: result.guidanceParagraph,
        summaryAnalysisText: result.summaryAnalysisText
      });


        // 延时 800ms 再跳转，保证有动画效果
        setTimeout(() => navigate("/result"), 800);
      } catch (error) {
        console.error(error);
        alert("Failed to analyze profile.");
      }
    };

    fetchAnalysis();
  }, [navigate, setOutput]);

  useEffect(() => {
    const interval = setInterval(() => {
      setStepIndex((prev) => (prev + 1) % steps.length);
    }, 2000);
    return () => clearInterval(interval);
  }, []);

  return (
    <div style={outerContainer}>
      <div style={innerContainer}>
        <h1 style={{ fontSize: "1.75rem", textAlign: "center", marginBottom: "1rem", color: "#031A47", lineHeight: "1.2" }}>
          Loading your personalized recommendation...
        </h1>

        <div style={{ textAlign: "center", marginBottom: "1rem" }}>
          <SpinnerSVG />
        </div>

        <p style={{ textAlign: "center", color: "#1f2937", fontSize: "0.95rem", lineHeight: "1.4" }}>
          {steps[stepIndex]}
        </p>

        <p style={{ marginTop: "0.8rem", textAlign: "center", fontSize: "0.85rem", color: "#6b7280" }}>
          Processing responses and generating your personalized pathway...
        </p>
      </div>
    </div>
  );
}

const outerContainer = {
  width: "100vw",
  minHeight: "100vh",
  backgroundColor: "#031A47",
  fontFamily: "'Segoe UI', 'Helvetica Neue', sans-serif",
  boxSizing: "border-box",
  padding: "2rem 7rem",
  display: "flex",
  justifyContent: "center",
  alignItems: "center"
};

const innerContainer = {
  backgroundColor: "#ffffff",
  borderRadius: "0",
  padding: "2rem 3rem",
  boxShadow: "0 4px 10px rgba(0,0,0,0.1)",
  width: "100%",
  maxWidth: "1000px",
  boxSizing: "border-box"
};
