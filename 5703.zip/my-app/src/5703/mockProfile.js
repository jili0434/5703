const mockProfile = {
  first_letter_surname: "J",
  gender: "Male",
  age: "18",
  first_language: "Japanese",
  other_language: "English",
  country_born: "China",
  current_country: "Australia",
  current_city: "Brisbane",
  type_of_school: "Private",
  secondary_qualification: "Australian Tertiary Admission Rank",
  work_experience: "Limited",
  dream_career: "Consultant",
  academic: "95",
  subject1: "",
  subject2: "",
  subject3: "",

  hedonism: "20",
  power_and_status: "27",
  altruism: "4",
  learning_and_achievement: "27",
  finance: "56",
  security: "39",

  artistic: "42",
  social: "13",
  investigative: "9",
  conventional: "20",
  enterprising: "10",
  realistic: "59",

  extrovert: 2,
  introvert: 0,
  sensing: 0,
  intuition: 2,  // ⚠️ intuition_n → intuition
  thinking: 4,
  feeling: 0,
  judging: 2,
  perceiving: 1,

  result: "ENTJ",
  q1: "16",
  q2: "9",
  q3: "26",

  father_education: "Certificate",
  mother_education: "Master",
  father_occupation: "Hearing Aid Specialist",
  mother_occupation: "Speech-Language Pathologist",
  annual_budget_usd: "50000",

  preferred_foe_1: "Healthcare",
  preferred_foe_2: "Scientist",
  preferred_foe_3: "",

  notes: "",
  concern: "unsure",
  support: "No",

  preferred_country: "New Zealand"
};

export default mockProfile;
