// Auto-generated JSX export

export const summaryAnalysisText = `
Based on our comprehensive understanding of this student's personality profile, interest distribution, and core values, I observe they have a balanced mix of creative and analytical skills, aligning well with their aspiration to pursue a career in IT and entrepreneurship. Their dream career suggests an interest in technology and innovation, but their personality profile hints at a solid foundation in logical thinking and practical applications.\nFirst, their high scores in Investigative (56) and Realistic (55) indicate strong analytical skills and a preference for hands-on problem-solving, essential for a career in IT. Furthermore, their solid Artistic score (52) shows they can think creatively, which is valuable in entrepreneurial ventures, particularly in tech businesses where innovative solutions are critical. Their Enterprising score (33) also suggests some inclination towards leadership and the management aspects of entrepreneurship, although it is relatively lower compared to their investigative strengths.\nIn their core values, they prioritize economic security (Finance) and stability (Security), which align with the generally lucrative nature of IT careers. However, they should also consider their score in Altruism (42), indicating that helping others is valuable to them. This could steer their entrepreneurial efforts towards solutions that provide societal benefits, integrating both profit and purpose.\nAs an ESTJ type, they tend to be organized, decisive, and enjoy structured environments, which can work well in both IT and entrepreneurial settings. They may thrive in roles that require project management or product development where clear frameworks and goals are set, allowing them to implement their ideas effectively.
`;

export const recommendedFOE = {
  title1: "0203 Information Technology",
  paragraphs1: [
    "After an in-depth analysis of this student's characteristics, my top recommended specific direction is: 0203 Information Technology. This field encompasses a wide range of specialties including software development, systems analysis, and IT project management, directly aligning with their dream of a career in IT and entrepreneurship, and supporting their strong analytical and practical abilities.",
    "This student shows a keen interest in problem solving (Investigative) and a practical inclination (Realistic) which are crucial in technological fields. They are likely to enjoy the challenges presented in IT, such as designing systems to solve user problems, optimizing technology for better results, or leading tech-focused projects.",
    "From a personality perspective, being an ESTJ, they excel in structured environments where leadership, organization, and efficiency are valued. They are likely to thrive in collaborative project teams where they can take initiative and make decisions, which aligns with entrepreneurial pursuits where leading a team is essential.",
    "Moreover, their family background is supportive of technical careers given their father’s profession in IT. With a healthy annual education budget, they can consider various pathways in this field, including reputable universities or specialized IT programs that provide hands-on experience.",
    "Qualification recommendation: The ideal qualification level for 0203 Information Technology is at least an undergraduate degree in computer science or a related field. Advanced certifications and experience through internships can greatly enhance career opportunities in this rapidly developing sector.",
  ],
  title2: "0803 Business and Management",
  paragraphs2: [
    "My second recommended direction is: 0803 Business and Management. This field closely aligns with their entrepreneurial aspirations and allows for the integration of their analytical skills with business acumen.",
    "The combination of their Investigative and Realistic scores suggests they not only enjoy understanding systems but also applying that knowledge in practical ways. In Business and Management, they can leverage their analytical skills to assess market trends, develop business strategies, and lead operations while also tapping into their creative side with product development or innovative marketing strategies.",
    "As an ESTJ, they thrive in managerial roles where they can organize team efforts toward shared goals, evaluate operational efficiencies, and implement structured plans. The practical application of business principles will allow them to explore entrepreneurial ventures effectively by combining their IT background with business strategies.",
    "Their family background, particularly with a mother in education who may also have insights into management practices, indicates a support structure that can inspire their journey into business.",
    "Qualification recommendation: The ideal qualification level for 0803 Business and Management is a bachelor’s degree in business administration or management, paired with practical experiences such as internships or part-time roles in tech companies.",
  ],
  title3: "0603 Engineering",
  paragraphs3: [
    "My third recommended direction is: 0603 Engineering. This field provides an excellent opportunity to apply their analytical thinking and technical skills in designing and developing solutions in technology-based industries.",
    "Given their high Realistic and Investigative scores, they could find themselves well-suited for engineering disciplines within the technology sector, where both hands-on applications and theoretical foundations are required. Engineering can encompass various areas, from software engineering to systems engineering, aligning well with both their interests in IT and entrepreneurial aspects.",
    "As an ESTJ, their organized and structured approach to problems will be advantageous in engineering projects, which often require meticulous planning and execution. They are likely to excel in contexts that demand teamwork, adherence to timelines, and the achievement of specific outcomes.",
    "Furthermore, considering the strong demand for skilled engineers in the job market, this field offers both stability and growth, aligning with their values of security and finance.",
    "Qualification recommendation: The ideal qualification level for 0603 Engineering is an undergraduate degree in engineering, computer science, or a related field, complemented by an internship or cooperative education experience to gain practical skills and industry knowledge.",
  ],
};

export const universityRecommendation1 = {
  university: "University of Toronto",
  major: "Bachelor of Commerce - Finance",
  note: "Focuses on developing strong financial analysis and decision-making skills applicable in various business contexts.",
  exam: "Australian Tertiary Admission Rank",
  score: "76.0/100 (76)",
  special: "None",
};

export const universityRecommendation2 = {
  university: "University of British Columbia",
  major: "Bachelor of Computer Science",
  note: "This program emphasizes software development, computer systems, and offers insights into entrepreneurship within the IT sector.",
  exam: "Australian Tertiary Admission Rank",
  score: "75.0/100 (75)",
  special: "None",
};

export const universityRecommendation3 = {
  university: "McGill University",
  major: "Bachelor of Commerce - Finance",
  note: "A comprehensive program that prepares students for careers in finance through a blend of theory and practical application.",
  exam: "Australian Tertiary Admission Rank",
  score: "85.0/100 (85)",
  special: "None",
};

export const universityRecommendation4 = {
  university: "University of Alberta",
  major: "Bachelor of Science in Computing Science",
  note: "This program focuses on programming, software engineering, and the application of computing technology in business.",
  exam: "Australian Tertiary Admission Rank",
  score: "78.0/100 (78)",
  special: "None",
};

export const universityRecommendation5 = {
  university: "Simon Fraser University",
  major: "Bachelor of Business Administration - Finance",
  note: "Designed to provide practical finance skills alongside entrepreneurial thinking, equipping students for a dynamic business environment.",
  exam: "Australian Tertiary Admission Rank",
  score: "76.0/100 (76)",
  special: "None",
};

export const universityRecommendations = [
  universityRecommendation1,
  universityRecommendation2,
  universityRecommendation3,
  universityRecommendation4,
  universityRecommendation5,
];

export const guidanceParagraph = `
To better align with your dream career in IT and entrepreneurship, consider enhancing your practical skills through hands-on projects or internships in the tech field, which could complement your academic background. Since your 'learning and achievement' score is low, focus on developing study habits or time management techniques to improve your performance in school. Participating in coding bootcamps, tech clubs, or online courses in programming and finance could enrich your skills and provide valuable experiences. Additionally, networking with professionals in the technology and business sectors through events or mentorship programs can offer insights and opportunities to pursue your career ambitions effectively.
`;

export const navItems = [
  { text: "Personal information analysis", path: "/", bg: "#d0ebff" },
  { text: "Recommended Field of Study", path: "/foe", bg: "#ffe3e3" },
  { text: "Suggested Universities and Majors", path: "/universities", bg: "#fff9db" },
  { text: "Next Step Guidance", path: "/guidance", bg: "#e6fcf5" },
];
