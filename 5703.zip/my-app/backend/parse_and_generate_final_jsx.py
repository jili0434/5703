
from openai import OpenAI
import pandas as pd
import os
from datetime import datetime
import re

def parse_and_generate_final_jsx(foe_text: str, uni_text: str, output_path: str = "final_output.jsx"):


    # summaryAnalysisText
    summary_match = re.search(r"1\.\s*Student basic information analysis:(.*?)(?=\n\s*\d\.|\Z)", foe_text, re.DOTALL)
    summary_text = summary_match.group(1).strip().replace('"', r'\"') if summary_match else "No summary analysis found."
    summary_lines = [line.strip() for line in summary_text.splitlines() if line.strip()]
    jsx_summary = "\\n".join(summary_lines)


    # ========== FOE 解析 ==========
    foe_pattern = re.findall(
        r"(?:Most|Second|third).*?FOE[:：]?\s*(\d{4})\s*([^\n]+)\n(.*?)(?=\n\d|^Recommendation|\Z)",
        foe_text,
        re.DOTALL
    )
    foe_structured = []
    for code, name, block in foe_pattern:
        title = f"{code} {name.strip()}"
        paras = [line.strip() for line in block.strip().split("\n") if line.strip()]
        foe_structured.append((title, paras))

    # ========== 大学推荐解析 ==========
    uni_blocks = re.findall(r"Recommendation\s*\d+\s*\n+(.*?)(?=\nRecommendation\s*\d+|\Z)", uni_text, re.DOTALL)
    uni_structured = []
    for block in uni_blocks:
        uni_info = {}
        for key in ["university", "major", "note", "exam", "score", "special"]:
            match = re.search(fr"{key}:\s*(.+)", block, re.IGNORECASE)
            uni_info[key.lower()] = match.group(1).strip() if match else "N/A"
        uni_structured.append({
            "university": uni_info["university"],
            "major": uni_info["major"],
            "note": uni_info["note"],
            "exam": uni_info["exam"],
            "score": uni_info["score"],
            "special": uni_info["special"]
        })
    # === 提取最后段 Improvement Suggestions 作为 guidanceParagraph ===
    guidance_match = re.search(r"Improvement Suggestions:\s*\n+(.*)", uni_text, re.DOTALL)

    guidance_text = guidance_match.group(1).strip() if guidance_match else "No improvement suggestions found."


    # ========== 写入为 JSX 文件 ==========
    with open(output_path, "w", encoding="utf-8") as f:
        f.write("// Auto-generated JSX export\n\n")

        # --- summaryAnalysisText ---
        f.write("export const summaryAnalysisText = `\n")
        f.write(jsx_summary)
        f.write("\n`;\n\n")

        # FOE 块
        f.write("export const recommendedFOE = {\n")
        for i, (title, paras) in enumerate(foe_structured, start=1):
            f.write(f'  title{i}: "{title}",\n')
            f.write(f'  paragraphs{i}: [\n')
            for p in paras:
                f.write(f'    "{p}",\n')
            f.write("  ],\n")
        f.write("};\n\n")

        # 大学推荐块
        for i, uni in enumerate(uni_structured, start=1):
            f.write(f"export const universityRecommendation{i} = {{\n")
            for k, v in uni.items():
                v_clean = v.strip('"').replace('"', r'\"')
                f.write(f'  {k}: "{v_clean}",\n')
            f.write("};\n\n")

        f.write("export const universityRecommendations = [\n")
        for i in range(1, len(uni_structured) + 1):
            f.write(f"  universityRecommendation{i},\n")
        f.write("];\n\n")


        # --- Dynamic guidanceParagraph ---
        f.write("export const guidanceParagraph = `\n")
        f.write(guidance_text)
        f.write("\n`;\n\n")

        # --- navItems ---
        f.write("export const navItems = [\n")
        nav_items = [
            {"text": "Personal information analysis", "path": "/", "bg": "#d0ebff"},
            {"text": "Recommended Field of Study", "path": "/foe", "bg": "#ffe3e3"},
            {"text": "Suggested Universities and Majors", "path": "/universities", "bg": "#fff9db"},
            {"text": "Next Step Guidance", "path": "/guidance", "bg": "#e6fcf5"},
        ]
        for item in nav_items:
            f.write(f'  {{ text: "{item["text"]}", path: "{item["path"]}", bg: "{item["bg"]}" }},\n')
        f.write("];\n")
        # Step 1：构建 recommendedFOE 为对象格式，而不是列表
        recommended_foe_dict = {}
        for i, (title, paras) in enumerate(foe_structured):
            recommended_foe_dict[f"title{i+1}"] = title
            recommended_foe_dict[f"paragraphs{i+1}"] = paras

        # Step 2：返回结构化数据
        return {
            "summaryAnalysisText": jsx_summary,  # ← 添加这一行
            "recommendedFOE": recommended_foe_dict,
            "universityRecommendations": uni_structured,
            "guidanceParagraph": guidance_text
        }