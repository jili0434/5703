// Auto-generated JSX export

export const summaryAnalysisText = `
Based on our comprehensive understanding of this student's personality profile, interest distribution, and core values, it is clear that they have a strong interest in social interaction and helping others, which aligns with their aspiration to become an influencer. Although they demonstrate moderate artistic skills, their high social interest suggests they thrive in environments where they can connect with others and build meaningful relationships. However, their lower scores in hedonism, finance, and security indicate that they may prioritize personal fulfillment over financial gain or stability in their career choices.\nIn terms of career interests, they have significant strengths in social interaction (Social) and practical abilities (Realistic). This combination is beneficial for their desired career as an influencer, where connecting with an audience, creating content, and engaging with fans are crucial components. Furthermore, their investigative score, albeit low, indicates a potential for analysis, which may come into play in understanding trends and audience preferences.\nFrom a values standpoint, their focus on altruism suggests they genuinely want to create a positive impact through their platform, which is an excellent trait for an influencer aiming to promote social causes or share meaningful content. Their personality type, INTP, indicates a tendency towards independent thinking and creativity, which can be advantageous in content creation, allowing them to carve out a unique niche in the influencer space.
`;

export const recommendedFOE = {
  title1: "1001 Communication and Media Studies",
  paragraphs1: [
    "After in-depth analysis of this student's characteristics, my top recommended specific direction is: 1001 Communication and Media Studies. This field closely aligns with their passion for becoming an influencer by focusing on content creation, audience engagement, and media strategies that can foster their social interests and altruistic values.",
    "This student possesses ample social ability and is drawn to creative expression, which is vital in effectively engaging audiences as a content creator. The Communication and Media Studies field offers hands-on learning opportunities in digital media, public relations, and marketing, allowing them to develop essential skills for establishing a strong online presence. Given their interest in social causes, they can specialize in areas such as social media marketing for non-profits, bringing visibility to important issues while building their personal brand.",
    "From a personality perspective, INTP students generally appreciate conceptual understanding and innovative approaches, making this discipline particularly suitable as it encourages free thinking and original content creation. The academic environment will also allow flexibility and creativity, appealing to this student's need for autonomy.",
    "Taking into consideration their family background, with a supportive educational budget and parents' occupations, they can likely access resources for internships and projects in media or marketing. This will foster networking opportunities and experience, crucial for career development in the influencer space.",
    "Qualification recommendation: The ideal qualification level for 1001 Communication and Media Studies would be at least a bachelor's degree, as this would provide both foundational knowledge and technical skills in communication strategies needed to thrive as an influencer. Further studies could concentrate on digital marketing or social media management, enhancing their understanding of audiences and content dissemination.",
  ],
  title2: "0804 Business and Management",
  paragraphs2: [
    "The second recommended field is: 0804 Business and Management. This direction allows them to understand commercial strategies, branding, and entrepreneurship, which can further benefit their influencer career by providing skills in marketing and managing their personal brand.",
    "This student shows a blend of enterprising and social interests, indicating they would indeed thrive in a business-focused environment where leadership and practical execution are essential. Studying Business and Management would equip them with a valuable framework for brand development, audience analysis, and market positioning.",
    "Being an INTP, they would likely excel in the analytical aspects of business, such as market research and strategic planning, allowing them to adeptly navigate the competitive influencer landscape. This field combines structure with creativity, helping to shape their business acumen while fostering their interest in helping others through socially conscious branding.",
    "Given their family's annual education budget, they have the potential access to quality programs that incorporate practical experiences—such as workshops and internships—that can provide real-world exposure to brand management and marketing strategies that resonate in the digital world.",
    "Qualification recommendation: A bachelor's degree in Business Administration would be the ideal starting point, as it would provide a robust foundation. Additionally, pursuing electives in digital marketing or entrepreneurship could further enhance their skill set and network.",
  ],
  title3: "0603 Arts",
  paragraphs3: [
    "The third recommended field is: 0603 Arts. This choice caters to their artistic inclinations and can combine their social interests in ways that promote their personal brand and content creation as an influencer.",
    "Pursuing a degree in Arts would allow this student to explore creative avenues, such as graphic design, multimedia arts, or performing arts, which can be integral to developing engaging content as an influencer. The program would provide opportunities to develop their artistic skills while honing their ability to communicate effectively with audiences.",
    "As an INTP, their independent and innovative thinking would flourish in an arts environment, enabling them to create distinctive content and build a unique personal style. Additionally, collaborating with peers in projects would help satisfy their social needs, allowing them to connect and engage within a creative community.",
    "Taking into account their family background, their parents' educational levels indicate a valuing of education, which can support the student in pursuing a degree in the arts. The available budget can facilitate pathways into various artistic disciplines that align with their influencer ambitions.",
    "Qualification recommendation: A bachelor's degree in a relevant Arts discipline would be the appropriate qualification level, as it would enable them to establish a portfolio and develop skills necessary for content creation and artistic expression as an influencer. Further specialization in areas like digital content creation or marketing within the arts could open doors to diverse opportunities in their future career.",
  ],
};

export const universityRecommendation1 = {
  university: "University of Auckland",
  major: "Bachelor of Commerce",
  note: "A comprehensive program focusing on business principles, management, finance, and marketing strategies.",
  exam: "International Baccalaureate",
  score: "28.0/45 (62.22/100)",
  special: "None",
};

export const universityRecommendation2 = {
  university: "Victoria University of Wellington",
  major: "Bachelor of Arts in Media Studies",
  note: "Explores media effects, communication theories, and techniques in digital production and design.",
  exam: "International Baccalaureate",
  score: "30.0/45 (66.67/100)",
  special: "None",
};

export const universityRecommendation3 = {
  university: "University of Otago",
  major: "Bachelor of Business",
  note: "Focuses on various aspects of business management, entrepreneurship, and industry practices.",
  exam: "International Baccalaureate",
  score: "29.0/45 (64.44/100)",
  special: "None",
};

export const universityRecommendation4 = {
  university: "AUT University (Auckland University of Technology)",
  major: "Bachelor of Communication Studies",
  note: "Emphasizes communication practices, media studies, and digital communication strategies.",
  exam: "International Baccalaureate",
  score: "30.0/45 (66.67/100)",
  special: "None",
};

export const universityRecommendation5 = {
  university: "Massey University",
  major: "Bachelor of Design (Communication Design)",
  note: "Combines design principles with digital production tools, focusing on visual communication.",
  exam: "International Baccalaureate",
  score: "31.0/45 (68.89/100)",
  special: "Portfolio required.",
};

export const universityRecommendations = [
  universityRecommendation1,
  universityRecommendation2,
  universityRecommendation3,
  universityRecommendation4,
  universityRecommendation5,
];

export const guidanceParagraph = `
"Although the dream career of becoming an influencer aligns with your interests, some aspects suggest a need for development in social engagement and creative expression. Your lower scores in hedonism and artistic inclination signal less enthusiasm for creative pursuits, which are often vital in content creation and audience interaction in the influencer sphere. Additionally, being identified as an INTP suggests a preference for analytical and independent work over extroverted, social environments.

To strengthen your potential in influencing, consider engaging in activities that enhance your creativity, such as content creation workshops or social media strategy courses. Participate in community events or online platforms where you can practice social interaction and gain visibility. Also, following successful influencers can provide insights into different styles and approaches.

If social media influencing does not feel fulfilling after such exploration, think about careers in marketing strategy or digital media analysis, where you can leverage your analytical strengths while staying within the digital realm. Setting specific, reachable goals—like creating a weekly content piece or attending networking events—can help you gradually acclimatize to social engagement while pursuing your favorite areas."
`;

export const navItems = [
  { text: "Personal information analysis", path: "/", bg: "#d0ebff" },
  { text: "Recommended Field of Study", path: "/foe", bg: "#ffe3e3" },
  { text: "Suggested Universities and Majors", path: "/universities", bg: "#fff9db" },
  { text: "Next Step Guidance", path: "/guidance", bg: "#e6fcf5" },
];
