from fastapi import FastAPI, Request, Query  # 加了 Query
from fastapi.middleware.cors import CORSMiddleware
import pandas as pd  # ⬅️ 加了 pandas
import sys
import os
from backend.main import generate_recommendation  # ✅ 你原本的

sys.path.append(os.path.dirname(os.path.abspath(__file__)))

app = FastAPI()

# CORS 允许跨域请求
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# ✅ 加载 CSV，路径根据你的结构，记得是 backend/full_data_with_labels.csv
df = pd.read_csv(os.path.join(os.path.dirname(__file__), 'full_data_with_labels.csv'))

@app.post("/api/analyze")
async def analyze(request: Request):
    try:
        profile = await request.json()
        print("✅ Received profile:", profile)

        result = generate_recommendation(profile)  # ✅ 返回结构化数据
        return result  # ✅ FastAPI 自动转为 JSON 响应
    except Exception as e:
        print("❌ Error in backend:", e)
        return {"error": str(e)}


# ✅ 新增 GET 接口，根据 identifier 查 profile
@app.get("/api/get_profile")
def get_profile(identifier: str = Query(...)):
    try:
        row = df[df["identifier"].astype(str) == identifier]
        if row.empty:
            return {"error": "Identifier not found"}

        row_data = row.iloc[0]

        profile = {
            "first_letter_surname": str(row_data["first_letter_surname"]),
            "gender": str(row_data["gender"]),
            "age": str(row_data["age"]),
            "first_language": str(row_data["first_language"]),
            "other_language": str(row_data["other_language"]),
            "country_born": str(row_data["country_born"]),
            "current_country": str(row_data["current_country"]),
            "current_city": str(row_data["current_city"]),
            "type_of_school": str(row_data["type_of_school"]),
            "secondary_qualification": str(row_data["secondary_qualification"]),
            "work_experience": str(row_data["work_experience"]),
            "dream_career": str(row_data["dream_career"]),
            "academic": str(row_data["academic"]),
            "subject1": str(row_data.get("subject1", "")),
            "subject2": str(row_data.get("subject2", "")),
            "subject3": str(row_data.get("subject3", "")),
            "hedonism": str(row_data["hedonism"]),
            "power_and_status": str(row_data["power_and_status"]),
            "altruism": str(row_data["altruism"]),
            "learning_and_achievement": str(row_data["learning_and_achievement"]),
            "finance": str(row_data["finance"]),
            "security": str(row_data["security"]),
            "artistic": str(row_data["artistic"]),
            "social": str(row_data["social"]),
            "investigative": str(row_data["investigative"]),
            "conventional": str(row_data["conventional"]),
            "enterprising": str(row_data["enterprising"]),
            "realistic": str(row_data["realistic"]),
            "extrovert": int(row_data["extrovert"]),
            "introvert": int(row_data["introvert"]),
            "sensing": int(row_data["sensing"]),
            "intuition": int(row_data["intuition_n"]),  # 注意
            "thinking": int(row_data["thinking"]),
            "feeling": int(row_data["feeling"]),
            "judging": int(row_data["judging"]),
            "perceiving": int(row_data["perceiving"]),
            "result": str(row_data["result"]),
            "q1": str(row_data["q1"]),
            "q2": str(row_data["q2"]),
            "q3": str(row_data["q3"]),
            "father_education": str(row_data["father_education"]),
            "mother_education": str(row_data["mother_education"]),
            "father_occupation": str(row_data["father_occupation"]),
            "mother_occupation": str(row_data["mother_occupation"]),
            "annual_budget_usd": str(row_data["annual_budget_usd (usd)"]),
            "preferred_foe_1": str(row_data["preferred_foe_1"]),
            "preferred_foe_2": str(row_data["preferred_foe_2"]),
            "preferred_foe_3": str(row_data["preferred_foe_3"]),
            "notes": str(row_data.get("notes", "")),
            "concern": str(row_data["concern"]),
            "support": str(row_data["support"]),
            "preferred_country": str(row_data["preferred_country"]),
        }


        return profile
    except Exception as e:
        print("❌ Error fetching profile:", e)
        return {"error": str(e)}
