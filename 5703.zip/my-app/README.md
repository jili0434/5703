# 🎓 Intelligent Study Abroad Advisory System

This project is an intelligent recommendation platform for academic advancement. It leverages a React-based frontend and a FastAPI-powered backend to generate personalized analysis reports, suggested fields of study, and university recommendations based on student-provided information.

---

## 📁 Project Structure Overview

```
MY-APP/
├── backend/                     # Backend services (FastAPI)
│   ├── api_server.py            # Main FastAPI service
│   ├── main.py                  # Backend entry point
│   ├── final_output.jsx         # Template for generated recommendations
│   ├── full_data_with_labels.csv# Dataset (cleaned result from Excel)
│   ├── parse_and_generate_final_jsx.py  # Data processing
│   ├── prepare_data.py          # Run full data cleaning + loading workflow
│   ├── data_cleaner.py          # Standardization, merging, null handling
│   ├── data_loader.py           # Load cleaned data into PostgreSQL
│   ├── table_manager.py         # (Optional) Create DB schema from SQL
│   ├── StudnetDatabase.sql      # Database schema
│   ├── Survey_result_2025(update).xlsx # Raw survey input
│   ├── validate_api_key.py      # API Key validation
│   └── prompt_uni_templates/    # Prompt templates
│
├── src/                         # Frontend source code
│   └── 5703/                    # Pages and components
│       ├── context/             # Global state management
│       ├── *.jsx                # Page components
│       ├── mockProfile.js       # Simulated user input (for debugging)
│       └── mockOutput.js        # Simulated backend response (for debugging)
│
├── assets/                      # Static assets
├── public/                      # Public directory
├── App.jsx / App.css / index.css / main.jsx
└── README.md

---

## ⚙️ Prerequisites

- Python 3.8+
- Node.js 16+
- npm 8+

### Python Dependencies
Make sure to install the required Python packages:

```
# backend/requirements.txt
openai>=1.3.8
pandas>=1.3.0
fastapi>=0.95.0
uvicorn[standard]>=0.18.3
```

---

## ⚙️Run Data Preprocessing (once)
If you are working with new or updated Excel data

### 1️⃣ Install Dependencies

```bash
pip install pandas openai psycopg2 sqlalchemy openpyxl
```

---
### 2️⃣ Configure Database (Required)

In `prepare_data.py`, set your PostgreSQL credentials:

```python
config = DBConfig(
    name="your_db_name",
    user="your_username",
    password="your_password",
    host="localhost",
    port="5432"
)
```
---

### 3️⃣ Set Your OpenAI API Key (Required)

In `main.py`, set OpenAI API Key:
---

### 4️⃣ Run Data Preparation (once)

```bash
python prepare_data.py
```

- Loads and cleans `Survey_result_2025.xlsx`
- Exports `cleaned_full_data.csv`
- (Optional) writes data into PostgreSQL tables

---

## 🚀 Quick Start Guide

Ensure you are in the root directory (`MY-APP`) and execute the following:

### 1. Install Dependencies

```bash
# Install backend dependencies (using virtual environment recommended)
pip install -r backend/requirements.txt

# Install frontend dependencies
npm install
```

### 2. Start Services

```bash
# Start FastAPI backend
uvicorn backend.api_server:app

# Start frontend Vite dev server
npm run dev
```

---

### 3. Open the Application
Once both backend and frontend services are running:

Open your browser and go to:
👉 http://localhost:5173

This will launch the homepage of the Intelligent Study Abroad Advisory System.


## 🔧 Key Features

-  🆔 Student ID Input: Users only need to enter a student ID to trigger the analysis process.
- 📊 Personalized Analysis: Generates visual charts like MBTI bars, value radar, and career interest.
- 🎯 Field Recommendations: Suggests top fields of study aligned with user's profile.
- 🎓 University Suggestions: Recommends institutions and majors, including admission criteria.
- 📘 Guidance Section: Offers follow-up academic and career planning advice.

---